# Laboratorio de inventos · flujo de usuario

**Exportado:** 6 de octubre de 2026.
**Qué describe:** el diseño de `web/` de este zip (la última versión de cada pantalla).
**Con qué se compara:** la app de hoy, la 1.2.0 de la rama `_ztool_dev`, leída de GitHub el 6 de octubre de 2026 a las 14:10 UTC y comparada archivo por archivo.

**Marcas de cada paso:**
- **same:** el diseño hace lo mismo que la app de hoy.
- **changed: …:** el diseño lo cambia, y dice qué cambia.
- **new:** no está en la app.
- **removed:** el diseño lo quita.

**«La app ya tiene además…»:** son mejoras que se hicieron al llevar el diseño a la placa y que el diseño no tiene. No son cambios que pida el diseño: hay que quedarse con lo de la app.

**Precios y créditos:** no hay. La app es gratuita, no tiene cuentas ni pagos. Lo que recuerda (récords, programas, retos, pegatinas) se guarda en el navegador de cada aparato (`localStorage`, prefijo `lab.`). Los récords de la clase los guarda la placa.

**Tamaños:**
- **Escritorio:** 1366 px de ancho.
- **Móvil:** 390 px, en vertical. Cuando cambia algo, cada paso lo dice en **📱 Móvil**.
- La web tiene que caber en 360 px.

**Estados de cada pantalla:**
- **Vacío:** todavía no hay nada.
- **Cargando:** esperando a la placa.
- **Error:** sin placa, sin sensor o una orden que falla.
- **Hecho:** funciona y enseña el resultado.

## Resumen

| Página | same | changed | new | removed |
|---|---|---|---|---|
| 0. Lo común (todas las páginas) | 8 | 0 | 0 | 0 |
| 1. Portada | 2 | 0 | 0 | 0 |
| 2. 🚦 Semáforo y «Luz roja, luz verde» | 6 | 1 | 0 | 0 |
| 3. 🎤 Sonómetro y «Duelo de palmadas» | 4 | 3 | 0 | 0 |
| 4. 👻 Detector y «Caza contrarreloj» | 5 | 1 | 0 | 0 |
| 5. 🎮 ¡Salta, Chispa! | 10 | 0 | 0 | 0 |

Los cuatro cambios del diseño son pequeños y no tocan la placa ni sus órdenes `/api`.

---

## 0. Lo común (lo usan todas las páginas)

**Archivos:** `web/app.js` y `web/app.css`. Las cinco páginas los usan.

### 0.1 Barra de arriba

**Estado:** same. La app ya enlaza la flecha ← a la raíz (`href=""`) en vez de a `index.html`. Se mantiene lo de la app.
- **Qué se ve:**
  - La flecha **←**, que lleva a la portada. No sale en la portada.
  - El título de la página.
  - La pastilla de conexión.
- **📱 Móvil (≤ 480 px):** el título es más pequeño, y «Detector de fantasmas» se queda en «👻 Detector».
- **Estados de la pastilla:**
  - Cargando: «Conectando…».
  - Hecho: «Conectado», en verde.
  - Error: «Sin conexión», en cuanto fallan dos preguntas seguidas a la placa.

### 0.2 Aviso sin placa

**Estado:** same
Sale sólo en el estado de error: «No encuentro la placa. ¿Está enchufada? ¿Sigues conectado a su wifi (**Laboratorio-…**)?». El nombre de la wifi aparece en cuanto la placa ha contestado alguna vez.

### 0.3 Pie

**Estado:** same. La app ya pone «versión 1.2.0» en el HTML; el diseño aún dice 1.1.0 hasta que contesta la placa (que es la que pone la versión). Se mantiene lo de la app.
«Laboratorio de inventos · versión **1.1.0** · placa **…**». La versión y el nombre los pone la placa.

### 0.4 Pestañas 🎮 Jugar · 🧩 Programar · 🔌 Montar

**Estado:** same
Están en el semáforo, el sonómetro, el detector y el juego.
- **Al pulsar una:** se ve su panel y se esconden los otros dos. La dirección cambia a `#jugar`, `#programar` o `#montar`.
- **Con el teclado:** con una pestaña elegida, ← y → pasan a la de al lado (después de la última vuelve la primera).
- **Al abrir una página:**
  - Con `#programar` o `#montar` en la dirección, se abre en esa pestaña. Los enlaces de «Paso a paso» lo usan, por ejemplo `semaforo.html#montar`.
  - Sin nada, se abre en **Jugar**.

### 0.5 Chispa, la ayudante

**Estado:** same
- Es una bombilla con un bocadillo, arriba de cada pestaña.
- El texto del bocadillo y su cara (contenta, sorprendida o asustada) cambian con lo que pasa. Cada paso dice qué textos salen.

### 0.6 Avisos y confeti

**Estado:** same
- **Avisos:** un mensaje corto abajo, durante 2,6 s. Uno nuevo sustituye al anterior.
- **Confeti:** 22 piezas (🎉 ⭐ ✨ 🎊 💛 🌟) que caen durante unos 2,4 s.

### 0.7 🏆 Retos (pestaña Programar)

**Estado:** same
- **Qué se ve:** una lista de retos con sus estrellas (⭐ a ⭐⭐⭐), y en el título el contador «⭐ N de M».
- **Qué se pulsa:** un reto. Cada reto es un botón que marca y desmarca el propio niño; la app no comprueba nada.
- **Qué pasa:**
  - Al marcarlo sale ✓, cae confeti y el aviso dice «¡Reto conseguido! 🏆».
  - Al desmarcarlo se quita el ✓, sin celebración.
- **Estados:**
  - Vacío: «⭐ 0 de M».
  - Hecho: los marcados con ✓. Se guardan en `retos.<página>`.

### 0.8 El editor de bloques (pestaña Programar)

**Estado:** same. La app ya tiene además dos cosas: un «⚡ cuando…» soltado dentro de otro bloque se va arriba, suelto; y si una rama falla o se para, se paran todas y se espera a que acaben antes de otro ▶. Se mantiene lo de la app.
**Archivo:** `web/bloques.js`.

**Qué se ve**
- A la izquierda, la **paleta** de bloques por familias: 💡 Luces, 🔊 Sonido, 🔁 Control y 📡 Sensores. En el juego hay además ⚡ Eventos.
- A la derecha, **tu programa**, que empieza siempre por el sombrero «🏁 al pulsar ▶ ¡Ejecutar!».
- Encima, cuatro botones: **▶ ¡Ejecutar!**, **■ Parar**, **💡 Ejemplo** y **🧹 Borrar**.

**📱 Móvil (< 900 px)**
- La paleta va arriba, pegada mientras se baja por el programa.
- Enseña una sola familia cada vez, con pestañas de familia, en una fila que se desliza de lado.
- En escritorio (≥ 900 px) se ven todas las familias en una columna de 360 px.

**Qué se hace y qué pasa**
| Acción | Resultado |
|---|---|
| Arrastrar un bloque de la paleta | Cae donde se suelta: en el programa, o dentro de un «repetir», «por siempre», «si…» o «⚡ cuando…». |
| Tocar un bloque de la paleta (sin arrastrar) | Se añade al final del programa o dentro del hueco elegido, que se ve resaltado. |
| Tocar el hueco de un bloque con hueco | Ese hueco pasa a ser donde caen los bloques. |
| Arrastrar un bloque fuera del programa | Mientras se arrastra se lee «🗑️ Suelta fuera para quitarlo». Al soltar fuera, el aviso dice «Bloque quitado 🗑️». |
| **×** de un bloque | Quita el bloque con todo lo que lleve dentro. |
| Escribir un número | Vale con coma (0,5). Al salir del hueco se ajusta a los límites del bloque. |
| Elegir en un desplegable (color, nota, comparación, suceso, poder) | Se guarda al momento. |
| Un bloque «⚡ cuando Chispa…» | Va siempre suelto en el programa, nunca dentro de otro. |
| Cambiar algo mientras el programa va | No se puede: el aviso dice «Para el programa (■) para cambiar los bloques». |

**Botones**
| Botón | Qué pasa |
|---|---|
| **▶ ¡Ejecutar!** | Sin bloques, el aviso dice «Primero pon algún bloque 😉». Con bloques, la placa lo hace paso a paso. El estado dice «▶ Ejecutando…», el bloque que va se resalta y los bucles dicen por qué vuelta van («2 de 3», «vuelta 4», «3 veces»). Mientras va, ▶ no se puede pulsar. Los «⚡ cuando…» esperan su momento a la vez que lo demás. |
| **■ Parar** | Lo para todo y el estado dice «■ Parado.». En el sonómetro y el detector, las luces vuelven al invento. |
| **💡 Ejemplo** | Si ya hay bloques, pregunta «¿Cambiar tu programa por el ejemplo?». Si se acepta, pone el ejemplo de esa página y el bocadillo explica el ejemplo. |
| **🧹 Borrar** | Si hay bloques, pregunta «¿Borrar todos los bloques?». Si se acepta, deja el programa vacío. |

**Estados**
- **Vacío:** sólo el sombrero 🏁 y el hueco: «Toca un bloque para ponerlo aquí debajo, o arrástralo. ¡Prueba con «encender»!».
- **Cargando:** «▶ Ejecutando…».
- **Error:** «😕 <qué ha pasado>. ¿Sigues conectado a la placa?», y el programa se para.
- **Hecho:** «✓ ¡Terminado! ¿Lo cambias y lo pruebas otra vez?». Un programa con «por siempre» o con «⚡ cuando…» sólo acaba con ■.

El programa se guarda con cada cambio (`programa.<página>`) y vuelve al recargar.

**Los bloques, como se leen**
- **Luces:** «encender [rojo / amarillo / verde]», «apagar [color]», «apagar todas».
- **Sonido:** «pitar [0,2] segundos» (de 0,05 a 5), «tocar [nota] durante [0,5] s».
- **Control:** «esperar [1] segundos» (de 0,1 a 60), «repetir [3] veces» (de 1 a 100), «por siempre».
- **Sensores** (cada página tiene los suyos):
  - Semáforo: «esperar a que pulsen el botón 🔘».
  - Sonómetro: «esperar a que el ruido sea [mayor / menor] que [60]» y «si el ruido es…».
  - Detector: «esperar a que algo esté a menos de [30] cm» y «si algo está a menos de…».
  - Juego: «esperar a que Chispa [suceso]» y «si Chispa tiene [🚀 el cohete / 🛡️ el escudo / ⏱️ la cámara lenta]».
- **Eventos** (sólo en el juego): «⚡ cuando Chispa [salte / choque / coja un rayo / coja un poder / pierda / gane / se agache / pase de fase]».

---

## 1. Primera visita: la portada

**Archivo:** `web/index.html` (en el repositorio, `web/index.html`). Es igual que la de hoy.

**Paso 1.1. Abrir la web**

**Estado:** same. La app ya enlaza las tarjetas sin «.html» (`semaforo`, `sonometro`, `fantasmas`, `juego`), el enlace `/api` lleva a `api` y el pie dice 1.2.0. Se mantiene lo de la app.
- **Qué se ve, de arriba abajo:**
  1. Chispa, contenta.
  2. «¡Hola! Soy Chispa 👋», el título «Laboratorio de inventos» y «Una placa, tres inventos, un juego y muchas ideas. ¿Por cuál empiezas?».
  3. La pastilla de conexión (0.1).
  4. Cuatro tarjetas, una por invento (abajo). Cada tarjeta entera es un enlace.
  5. «¿Cómo se juega?»: 🔌 Monta · 🎮 Juega · 🧩 Programa.
  6. «Para profes y familias»: qué enseña cada invento, el nombre de la wifi de la placa, la dirección `http://192.168.4.1` y un enlace a la lista de órdenes `/api`.
  7. El pie.
- **📱 Móvil:**
  - Las tarjetas van de una en una (< 640 px), de dos en dos hasta 1000 px y de cuatro en fila desde 1000 px.
  - El título es más grande a partir de 720 px.
- **Qué pasa:** la portada pregunta a la placa cada 1,5 s cómo está. No cambia nada en la placa.
- **Estados:**
  - Cargando: «Conectando…» y «placa …» en el pie.
  - Error: aviso sin placa y «Sin conexión».
  - Hecho: «Conectado» y el nombre de la placa.
  - No tiene estado vacío.

**Las cuatro tarjetas**
| Tarjeta | Nivel | Texto | Necesitas | Botón | Lleva a |
|---|---|---|---|---|---|
| Semáforo | ⭐ Para empezar | «Enciende las luces, ponlo en automático y programa tu propia secuencia.» | 3 LEDs y 3 resistencias | ¡Vamos! | `semaforo.html` |
| Sonómetro | ⭐⭐ Un poco más | «¿Cuánto ruido hay? Las luces del semáforo te lo dicen. ¿Aguantáis en verde?» | el semáforo y un micrófono | ¡Vamos! | `sonometro.html` |
| Detector de fantasmas | ⭐⭐⭐ Para valientes | «Un radar que avisa cuando algo se acerca… ¿o es alguien?» | el semáforo y un sensor de distancia | ¡Vamos! | `fantasmas.html` |
| ¡Salta, Chispa! | 🎮 Para jugar | «Corre y salta como el dinosaurio de Chrome… pero con el botón de la placa, una palmada o la mano.» | la placa (y, si quieres, el micrófono o el sensor) | ¡A jugar! | `juego.html` |

**Paso 1.2. Elegir un invento**

**Estado:** same
- **Qué se pulsa:** una tarjeta.
- **Qué pasa:** se abre esa página en la pestaña **Jugar**, con todo lo guardado de antes.
- El enlace `/api` abre la lista de órdenes en la placa. En `web/index.html` de este zip es `#` y no hace nada; la app ya enlaza a `api`.

---

## 2. 🚦 Semáforo

**Archivos:** `web/semaforo.html` y `web/semaforo.js`.

**Paso 2.1. Llegar**

**Estado:** changed: «🟢🔴 Luz roja, luz verde» va debajo del semáforo y de «¿Quién manda?», a todo lo ancho. En la app está arriba del todo, antes del semáforo, y el bocadillo «Toca una luz para encenderla» queda lejos de las luces (en el móvil, una pantalla más abajo).
- **Qué pasa:** si las luces de la placa las tenía el sonómetro o el detector, la página pone la placa en **Automático**. Pregunta a la placa cada 350 ms.
- **Qué se ve en Jugar:**
  1. El bocadillo.
  2. El semáforo grande con el semáforo de peatones y el botón «🔘 Quiero cruzar».
  3. «¿Quién manda?».
  4. Debajo, a todo lo ancho, «🟢🔴 Luz roja, luz verde».
- **📱 Móvil (< 860 px):** las tarjetas van una debajo de otra. En escritorio, el semáforo y «¿Quién manda?» van lado a lado.
- **Estados:**
  - Cargando: luces apagadas y «Conectando…».
  - Error: aviso sin placa; los botones dan el aviso «😕 <qué ha pasado>».
  - Hecho: las luces copian las de la placa.

**Qué dice el bocadillo**
| Lo que pasa en la placa | Bocadillo |
|---|---|
| Automático y peatones cruzando | «¡Rojo para los coches: ya pueden cruzar los peatones! 🚶» |
| Automático | «Automático: verde, amarillo, rojo… ¿Quieres cruzar? ¡Pulsa el botón!» |
| Noche | «Modo noche: el amarillo parpadea. Quiere decir «¡cuidado!».» |
| Yo | «Tú mandas: toca las luces para encenderlas y apagarlas.» |
| Las luces las tiene otro invento | «Las luces las tiene otro invento. Elige un modo para recuperarlas.» |

El bocadillo no cambia mientras va un programa o «Luz roja, luz verde».

**Paso 2.2. Tocar las luces**

**Estado:** same
- **Qué se pulsa:** la luz roja, la amarilla o la verde.
- **Qué pasa:**
  - La placa pasa a **Yo** (manual).
  - Esa luz se enciende, o se apaga si ya estaba encendida en Yo. El LED de verdad hace lo mismo.
  - El semáforo de peatones se pone verde con el rojo encendido; en Noche se apaga.

**Paso 2.3. Quiero cruzar**

**Estado:** same
- **Qué se pulsa:** «🔘 Quiero cruzar», o el botón FLASH de la placa.
- **Qué pasa:**
  - En Automático, el verde se corta pronto (después de 1 s como mínimo), luego amarillo y luego rojo con el peatón en verde.
  - En otro modo, el aviso dice «El botón de peatones funciona en automático 🔄».

**Paso 2.4. ¿Quién manda?**

**Estado:** same
- **Qué se pulsa:** «🖐️ Yo», «🔄 Automático» o «🌙 Noche».
- **Qué pasa:** la placa cambia de modo y el botón elegido se resalta.
- **Velocidad:** sólo en Automático sale «Velocidad del automático»: 🐢 Tortuga · 🚶 Normal · 🐇 Liebre. Se guarda en la placa; en la placa de mentira de `preview/`, el verde, el amarillo y el rojo duran 8/3/8 s, 5/2/5 s o 3/1/3 s.

**Paso 2.5. Luz roja, luz verde**

**Estado:** same. La app ya tiene además: con 40 cm justos también pide «Aléjate un poco», y al llegar Chispa sigue celebrando hasta que el semáforo vuelve a automático (2,5 s). Se mantiene lo de la app.
- **Qué se pulsa:** **¡Empezar!**
- **Qué pasa:**
  - Sin eco del sensor de distancia: aviso «📏 No te veo: ponte delante del sensor de distancia». No empieza.
  - A menos de 40 cm: aviso «📏 Aléjate un poco: a más de 40 cm de la placa». No empieza.
  - Si no, empieza. La distancia de ese momento es la **salida**, el botón pasa a «■ Parar» y la placa se pregunta cada 150 ms.
- **La partida.** Las luces de la placa siguen las fases, y el recuadro de encima de la pista dice en cuál estás:
  1. **🟢 ¡Avanza!**, entre 2 y 4,5 s al azar. Bocadillo «¡Verde! Avanza hacia la placa… 🚶».
  2. **🟡 ¡Atento!**, 0,8 s.
  3. **🔴 ¡Quieto!**, entre 2 y 3,5 s al azar, con un pitido corto. Bocadillo «¡Rojo! Ni un pelo… 👀». Hay 0,45 s para pararse; después, moverse más de **6 cm** cuenta.
  4. **Si te pilla:** «👀 ¡Te he visto! Vuelve a la salida (N cm)», un pitido grave y el bocadillo «¡Te he visto moverte! A la salida…», con Chispa asustada. Al volver a menos de 10 cm de la salida, otra vez verde.
  5. Y vuelta a empezar por el verde.
  - En la pista, 🚶 avanza de «Salida» a 🏁. En medio se lee «📏 N cm».
- **Hecho.** Al llegar a **12 cm o menos**, en cualquier fase menos cuando te ha pillado:
  - «🏁 ¡Has llegado en X,Y s!», más «🏆 Récord» si es tu mejor tiempo y «· te pilló N vez / veces» si te pilló.
  - Luz verde, confeti y el bocadillo «¡Has llegado a la placa! 🏁». El botón dice «¡Otra vez!».
- **Parar.** Si se pulsa **■ Parar** durante la partida: «Parado. Cuando quieras, ¡otra vez!».
- **Al acabar** (llegando o parando), 2,5 s después el semáforo vuelve a Automático.
- **Estados:**
  - Vacío: «Récord: —» y «Ponte delante del sensor, a más de 40 cm de la placa, y pulsa «¡Empezar!»».
  - Error: los dos avisos de 📏.
  - Hecho: el tiempo. Se guarda el más bajo en `semaforo.luzroja` y se enseña con coma, por ejemplo «12,4 s».

**Paso 2.6. Programar**

**Estado:** same
- **Bocadillo:** «Pon bloques en orden para hacer tu secuencia de luces y pulsa ▶ ¡Ejecutar! El semáforo de verdad hará lo mismo, paso a paso.»
- **Bloques:** luces, sonido, control y «esperar a que pulsen el botón 🔘».
- **Ejemplo:** repetir 3 veces verde 3 s, amarillo 1 s y rojo 3 s. Su texto: «El semáforo de siempre, 3 veces. ¿Te atreves a hacerlo más rápido?».
- **Retos (5):**
  - Las tres luces a la vez.
  - La secuencia con «esperar».
  - Repetirla 5 veces con «repetir».
  - El amarillo parpadeando por siempre.
  - Un semáforo de peatones.

**Paso 2.7. Montar.** Se lee, no se toca:

**Estado:** same
- «Lo que necesitas» (6 cosas).
- «Cómo se conecta»: el dibujo (LEDs y zumbador resaltados) y la tabla de pines D5, D6, D7, GND, D8 y D3.
- «Paso a paso» (6 pasos) y un consejo sobre las resistencias.
- **📱 Móvil (< 640 px):** encima del dibujo sale «↔ Desliza el dibujo para verlo entero.». La tabla de pines va más apretada por debajo de 520 px.

---

## 3. 🎤 Sonómetro

**Archivos:** `web/sonometro.html` y `web/sonometro.js`.

**Paso 3.1. Llegar**

**Estado:** same
- **Qué pasa:** la placa se pone en modo **sonido**: sus luces enseñan el ruido mientras la página está abierta. La página pregunta a la placa cada 250 ms.
- **Qué se ve en Jugar:**
  1. El bocadillo.
  2. La aguja (de 0 a 100, con zonas verde, amarilla y roja) y el semáforo pequeño.
  3. «Los últimos 30 segundos»: la gráfica del ruido.
  4. «Juegos»: el reto del silencio y el récord de palmada.
  5. «⚔️ Duelo de palmadas».
  6. «Ajustes».
- **📱 Móvil (< 860 px):** las tarjetas van una debajo de otra.
- **Estados:**
  - Cargando: aguja en 0.
  - Error sin micrófono: «No oigo nada… ¿Está el micrófono conectado a A0? Mira la pestaña «Montar».».
  - Hecho: la aguja se mueve. La marca de pico se queda 2 s en lo más alto.

**Qué dice la cara**
| Ruido | Cara y texto | Bocadillo |
|---|---|---|
| desde el rojo | 🙉 «¡Demasiado ruido!» | «¡Uf, qué jaleo! ¡Me tapo los oídos!» |
| desde el amarillo | 😮 «¡Cuánto jaleo!» | «Eso ya es bastante ruido… ¡amarillo!» |
| desde la mitad del amarillo | 🙂 «Ruido tranquilo» | «Se oye algo, pero tranquilo: verde.» |
| por debajo | 🤫 «Silencio» | «Shhh… qué silencio. ¡Da una palmada a ver qué pasa!» |

**Paso 3.2. Reto del silencio**

**Estado:** changed: si hay un duelo en marcha, «¡Empezar!» avisa «Espera a que acabe el duelo 😉». En la app no hace nada.
- **Qué se pulsa:** **¡Empezar!**
- **Qué pasa:** el botón se bloquea. Sale «3…», «2…», «1…» (0,8 s cada uno) y luego «¡Silencio! 🤫», mientras una barra se llena en 10 s.
- **Error:** si se llega al amarillo, «¡Uy! Se oyó algo (N). ¿Otra vez?».
- **Hecho:** «¡Conseguido! Diez segundos en verde. 🏆», confeti y el aviso «¡10 segundos de silencio! 🏆». El botón dice «¡Otra vez!».

**Paso 3.3. Récord de palmada**

**Estado:** changed: si hay un duelo en marcha, «¡Medir!» avisa «Espera a que acabe el duelo 😉». En la app no hace nada.
- **Qué se pulsa:** **¡Medir!**
- **Qué pasa:** «¡Ahora! ¡Una palmada fuerte! 👏». Escucha 3 s.
- **Hecho:**
  - Si es la mejor: «¡Nuevo récord! **N** 🎉» y confeti. Se guarda en `sonometro.record`.
  - Si no: «Tu palmada: **N**. Récord: **M**».
- **Vacío:** «Récord: —».

**Paso 3.4. Duelo de palmadas**

**Estado:** changed: en cada turno cuenta también el pico de la placa, si ha subido después del «AHORA». En la app sólo cuenta el nivel, que se pregunta cada 100 ms, así que una palmada corta puede contar poco o nada. La app ya tiene además: si empieza la revancha mientras parpadea la luz del ganador, el parpadeo se corta. Se mantiene lo de la app.
- **Qué se pulsa:** **¡Empezar el duelo!**
- **Qué pasa al empezar:** la luz de la placa se pone amarilla y se pregunta cada 100 ms.
- **Cada turno** (primero el rojo, luego el verde):
  - «Ronda N de 3 · Equipo rojo, preparados… 3 / 2 / 1» (0,7 s cada número). La tarjeta del equipo que juega se resalta.
  - Luego «¡Equipo rojo, **AHORA**! 👏» durante 2,5 s, con una barra que se llena. La tarjeta dice «¡Ahora! N» con lo más fuerte hasta entonces.
  - Cuentan el nivel y el pico de la placa, pero sólo el pico que sube después del «AHORA».
- **Entre turnos:** «🔴 El rojo ha hecho **N**. Ahora, el verde…».
- **Al acabar cada ronda:**
  - «Ronda N para el **rojo**, X a Y» (o para el verde), o «Ronda N: ¡empate a X!».
  - La luz de la placa dice quién va ganando: roja, verde, o amarilla si van empatados.
  - Cada tarjeta enseña sus palmadas, por ejemplo «Palmadas: 92 · 85».
- **Hecho** (cuando un equipo llega a 2 puntos o tras la ronda 3):
  - Si gana uno: «🏆 ¡Gana el equipo **rojo**, 2 a 0!», confeti y el aviso «¡Gana el equipo rojo! 🏆». Su LED parpadea 4 veces.
  - Si empatan: «🤝 ¡Empate, 1 a 1! ¿La revancha?».
  - El botón dice «¡La revancha!». Las luces vuelven al modo sonido.
- **Vacío:** «0» y «Todavía sin palmadas» en las dos tarjetas, y «Empieza el rojo. Cuando ponga «AHORA», ¡palmada!».
- **Error:**
  - «Espera a que acabe el otro juego 😉» si va el silencio o la palmada.
  - Si se pulsa «¡Empezar!» o «¡Medir!» durante el duelo: «Espera a que acabe el duelo 😉».

**Paso 3.5. Ajustes**

**Estado:** same
- **Deslizadores:**
  - «🟡 Amarillo a partir de» (de 5 a 95).
  - «🔴 Rojo a partir de» (de 10 a 100). El amarillo siempre queda por debajo del rojo: si se cruzan, el otro se mueve.
  - «🎚️ Sensibilidad del micrófono» (de 25 a 400 %, de 25 en 25).
  - Los tres se envían a la placa al soltar.
- **Interruptor:** «🔔 Pitar si hay demasiado ruido». Se envía al momento.
- **Qué pasa:** la aguja, la gráfica, los juegos y la palmada que hace saltar a Chispa usan estos números.
- **Error:** el aviso dice «😕 <qué ha pasado>».

**Paso 3.6. Programar**

**Estado:** same
- **Bloques:** luces, sonido, control, y «esperar a que el ruido sea…» y «si el ruido es…».
- **Ejemplo:** la alarma de jaleo. Su texto: «La alarma de jaleo: verde hasta que el ruido pasa de 70… ¡y entonces rojo y pitido!».
- **Al parar o acabar:** la placa vuelve al modo sonido.
- **Retos (6).**

**Paso 3.7. Montar.**

**Estado:** same
- Las piezas, el dibujo y los pines A0, 3V3 y GND.
- Cinco pasos y un consejo sobre el tornillito de los KY-038.

---

## 4. 👻 Detector de fantasmas

**Archivos:** `web/fantasmas.html` y `web/fantasmas.js`.

**Paso 4.1. Llegar**

**Estado:** same
- **Qué pasa:** la placa se pone en modo **fantasma**: sus luces avisan mientras la página está abierta. La página pregunta a la placa cada 250 ms.
- **Qué se ve en Jugar:**
  1. El radar, con los anillos de «amarillo» y «rojo», la distancia, el estado y las 5 barras de «Energía espectral».
  2. La tarjeta del fantasma: el fantasma, el contador, la caza contrarreloj y el semáforo pequeño.
  3. «Ajustes».
- **📱 Móvil (< 860 px):** las tarjetas van una debajo de otra. En escritorio, el radar ocupa dos filas.
- **Estados:**
  - Cargando: «—» y «Todo tranquilo… 😴».
  - Error sin eco: «El radar no recibe ningún eco. ¿Está bien conectado el sensor (TRIG a D1, ECHO a D2)? Mira la pestaña «Montar».».
  - Hecho: el fantasma del radar se mueve con la distancia.

**Los niveles de energía**
| Nivel | Cuándo | Estado y bocadillo |
|---|---|---|
| 0 | sin eco, o más lejos que «amarillo» | «Todo tranquilo… 😴» · «Todo tranquilo. Apunta el sensor a la puerta y espera…» |
| 1 | dentro de «amarillo», lejos | «Algo se mueve a lo lejos… 👀» |
| 2 | dentro de «amarillo», más cerca | «Se acerca algo… 👀» |
| 3 | dentro de «amarillo», cerca | «¡Está cerca! 😨» (Chispa asustada) |
| 4 | dentro de «rojo» | «¡Fantasma cerca! 😱» |
| 5 | a la mitad de «rojo» o menos | «¡¡ESPECTRO DETECTADO!! 👻» · «¡¡BUUU!! ¡Foto, foto! 📸» |

**Paso 4.2. Cazar**

**Estado:** same
- **Qué se hace:** acercar algo al sensor hasta el nivel 5.
- **Qué pasa:** cada vez que se llega a 5 desde abajo (como mucho una vez cada 2 s):
  - La pantalla hace un flash blanco y sale «¡BUUU!».
  - «📸 Fantasmas cazados» sube 1. Se guarda en `fantasmas.cazados`.
  - El aviso dice «📸 ¡Fantasma cazado! Ya llevas N.».
- **Empezar de cero** pone el contador a 0.
- **Vacío:** «📸 Fantasmas cazados: 0».

**Paso 4.3. Caza contrarreloj**

**Estado:** changed: a las 0:00, el reloj grande se queda 4 s con el resultado y se esconde. En la app se queda en «⏱ 0:00» encima del fantasma hasta recargar la página.
- **Qué se pulsa:** **¡Un minuto!**
- **Qué pasa al empezar:**
  - El botón se bloquea.
  - Sale un reloj grande encima del fantasma: «⏱ 1:00 · 👻 0 cazados».
  - El texto dice «¡A cazar! Lleva el detector hasta el 5, una y otra vez.».
- **Durante el minuto:** cada caza suma en el reloj, con el aviso «📸 ¡Uno más! Llevas N en este minuto.». En los últimos 10 s el reloj se pone urgente.
- **Hecho** (a las 0:00):
  - «¡Tiempo! N fantasmas en un minuto.», más «🏆 ¡Récord nuevo!» si lo bate, y el aviso «⏱ ¡Tiempo! N cazados». Confeti si es récord.
  - El botón dice «¡Otra vez!». El reloj se queda 4 s y se va.
  - El récord es la mayor caza en un minuto. Se guarda en `fantasmas.contrarreloj`.
- **Vacío:** «Récord: —».

**Paso 4.4. Ajustes**

**Estado:** same
- **Deslizadores:**
  - «🔴 Rojo si está a menos de» (de 5 a 100 cm).
  - «🟡 Amarillo si está a menos de» (de 15 a 300 cm, de 5 en 5). El rojo queda siempre al menos 5 cm por debajo del amarillo.
  - Los dos se envían al soltar.
- **Interruptor:** «🔊 Pitidos de radar en la placa». Se envía al momento.

**Paso 4.5. Programar**

**Estado:** same
- **Bloques:** luces, sonido, control, y «esperar a que algo esté a menos de… cm» y «si algo está a menos de… cm».
- **Ejemplo:** la trampa para fantasmas.
- **Al parar o acabar:** la placa vuelve al modo fantasma.
- **Retos (6).**

**Paso 4.6. Montar.**

**Estado:** same
- Las piezas, el dibujo y los pines VIN, GND, D1, D2 (con las dos resistencias) y D8.
- Siete pasos y un consejo para el HC-SR04P.

---

## 5. 🎮 ¡Salta, Chispa!

**Archivos:** `web/juego.html` y `web/juego.js`.

**Paso 5.1. Llegar**

**Estado:** same. La app ya tiene además: en marcos estrechos (menos de 560 px y menos de 350 px de ancho) los botones de las esquinas del inicio se encogen, hasta quedarse sólo con el dibujo, para que no se pisen. Se mantiene lo de la app.
- **Qué se ve:**
  - El marco del juego, con una partida de demostración detrás del cartel de inicio. La demostración no cuenta ni enciende la placa.
  - La barra de botones.
  - Las pestañas Jugar, Programar y Montar, debajo del juego.
- **Qué vuelve de la última vez:** el mundo, 1 o 2 jugadores, la velocidad, el color de Chispa, el sonido y los mandos.
- **📱 Móvil (≤ 600 px en vertical):**
  - El marco es más alto (78 % del ancho; en escritorio, 37,5 %).
  - Sale «📱 Gira el móvil para ver el juego más grande.».
  - Con el marco por debajo de 270 px de alto (por ejemplo, con dos jugadores en el móvil) se esconden las fichas de mandos y la parte larga de los botones de las esquinas.
- **Estados:**
  - Cargando: «Buscando la placa…».
  - Error: «Sin placa: juega tocando la pantalla o con la barra espaciadora.». El juego funciona igual con la pantalla y el teclado.
  - Hecho: «Placa lista: ¡prueba tu mando!».

**Paso 5.2. El cartel de inicio**

**Estado:** same. La app ya da a los botones de las esquinas su nombre para lectores de pantalla («1 jugador», «Tortuga: 5 vidas»…). Se mantiene lo de la app.
| Qué se pulsa | Qué pasa |
|---|---|
| «👤 1 jugador» / «👥 2 jugadores» (arriba a la izquierda) | Se resalta el elegido. Se guarda en `juego.jugadores`. |
| «🐢 Tortuga · 5 vidas» / «🐇 Normal» (arriba a la derecha) | Se guarda en `juego.tortuga`. |
| ‹ o › junto a «Mundo 1 · El campo 🌵» | Pasa de mundo: el campo, la granja, la luna, y vuelta. Cambian la demostración y «Lo que te vas a encontrar». Se guarda en `juego.mundo`. |
| Un mundo cerrado | ▶ no se puede pulsar, y sale «🔒 Se abre ganando a la Cosechadora en <el mundo anterior>». |
| **▶ ¡A jugar!**, Intro o espacio | Empieza la partida (5.3). |
| Tocar el juego fuera del cartel, espacio, ↑, o un mando de la placa encendido | También empieza. |

Debajo de ▶ salen fichas con los mandos:
- **Con un jugador:** «👆 Tocar» siempre encendida, y «🔘 Botón», «👏 Palmada» y «👋 Mano» encendidas o tachadas según «¿Con qué saltas?».
- **Con dos:** «J1 · 🔘 botón · tecla A · tocar arriba» y «J2 · 👏 palmada · tecla L · tocar abajo».

**Paso 5.3. Jugar (un jugador)**

**Estado:** same. La app ya tiene además: al empezar, el botón ▶ suelta el foco (así la barra espaciadora salta y no vuelve a empezar), y la pegatina «3 escudos» sale después del cartel del poder, sin taparlo. Se mantiene lo de la app.
- **Al empezar:**
  - El cartel «¡Corre, Chispa! ⚡», o «🐢 Modo tortuga: 5 vidas».
  - 3 vidas (5 en tortuga).
  - La luz de la placa se pone verde.
- **Saltar** (sólo desde el suelo; con el cohete, los saltos vuelan):
  - tocar el juego o «⤴ ¡Salta!»
  - espacio, ↑ o Intro
  - el botón FLASH, si «Botón» está encendido
  - una palmada que llegue al rojo del sonómetro, si «Palmada» está encendida
  - la mano a menos de 15 cm, si «Mano» está encendida (cuenta una vez, al entrar)
- **Agacharse** (sólo desde el suelo; Chispa se hace más baja y ancha):
  - mantener ↓ o S
  - mantener «⤵ Agáchate»
  - la mano entre 15 y 30 cm, si «Mano» está encendida
- **En el camino:**
  - Los obstáculos de cada mundo.
  - El Nubarrón («¡Cuidado! ¡El Nubarrón tira exámenes! ☁️»). Lo primero que tira es un **examen volador** ✈️ a la altura de la cabeza: hay que agacharse o saltarlo.
- **Lo que ayuda:**
  - 🛡️ el escudo aguanta un golpe.
  - 🚀 el cohete hace volar los saltos 8 s (14 s ante la Cosechadora).
  - ⏱️ la cámara lenta lo frena todo 6 s.
  - ⚡ los rayos suman en el marcador y en la hucha de colores.
  - En el marcador, cada poder tiene un anillo que se vacía.
- **Marcador:**
  - Vidas y rayos en una sola pastilla.
  - Los metros, dentro de la barra del camino hasta la Cosechadora, en 800 m.
  - Arriba, «Récord N m» (con 🐢 delante en el modo tortuga).
- **Al chocar:**
  - Se pierde una vida, con 1,5 s sin daño.
  - La pantalla tiembla.
  - Destello rojo en la placa, con pitido sólo si la palmada está apagada.
- **El cielo:** pasa por día, tarde y noche con los metros. En la luna siempre es de noche.
- **A los 800 m, la Súper Cosechadora** en tres fases, cada una con su cartel: «Pacas de paja» → «Tres saltos seguidos» → «¡Con el cohete!». Se asoma por la derecha y tira las pacas.
- **Luces de la placa** (sólo con placa y sin un programa de bloques en marcha):
  - al empezar, verde
  - al coger un poder, amarillo (con pitido si la palmada está apagada)
  - al chocar, un destello rojo
  - al perder, rojo
  - al ganar, un baile de luces y al final todas encendidas

**Paso 5.4. Fin de partida**

**Estado:** same. La app ya tiene además: al acabar vuelve a pedir los récords a la placa (por si ha entrado alguien desde otra tableta); si al guardar ya no entras, avisa «Esta vez no entras: mientras jugabas, otros han llegado más lejos»; limpia el alias igual que la placa (`laboratorio/alias.h`); y manda el mundo a la placa en inglés (`field`, `farm`, `moon`). Se mantiene lo de la app.
- **Qué se ve a la izquierda:**
  - El dibujo de lo que te ha pillado.
  - «¡Te ha pillado X!», o «¡Te han pillado X!» si es plural (por ejemplo, «los deberes»).
  - «📏 N m · ⚡ N rayos · ⤴ N saltos».
  - La barra del camino y «Te faltaban **N m** para la Súper Cosechadora 🚜», o «¡Estabas ante la Súper Cosechadora! 🚜».
  - «🏆 ¡Récord nuevo!» o «Récord: N m». Se guarda en `juego.record`.
  - Las novedades: «🆕 Pegatina: …», «🎨 ¡Nueva Chispa: …!».
  - **↻ ¡Otra vez!** (ya elegido) y **☰ Menú**.
- **📱 Móvil (≤ 600 px en vertical):** se esconden el dibujo, la barra y el «Te faltaban…».
- **A la derecha, «🏆 Récords de la clase»:**
  - Si entras entre los 5 mejores: «¡Entras en el puesto N!», el hueco «Tu alias» (12 letras como mucho, con el último alias puesto), **🎲**, **Guardar** y «Un alias, no tu nombre de verdad. **No, gracias**».
  - 🎲 pone un alias al azar (Rayo, Cometa, Trueno, Pulga, Bólido…).
  - Guardar con el hueco vacío: aviso «Escribe un alias (o pulsa 🎲)».
  - Guardar con un alias: se quitan `<>"&`, se guarda, la lista se pinta con tu fila resaltada y sale «✓ Guardado en la placa.» o «✓ Guardado en esta tableta.».
  - No, gracias: se cierra sin guardar.
  - Si no entras y la lista está llena: «Para entrar, hay que pasar de N m.».
  - Cada fila lleva el puesto, el alias (🐢 si fue en tortuga, y el emoji del mundo si no es el campo) y los metros.
  - **📱 Móvil:** en un marco bajo, esta columna va debajo de la otra en vez de al lado.
- **Para que un salto tardío no empiece otra partida**, durante 0,9 s los toques y los mandos no hacen nada. Los botones van al momento. Mientras está abierto el hueco del alias, ningún mando empieza otra partida.
- **Estados de los récords:**
  - Vacío: «Todavía nadie. ¡Estrénalos!».
  - Hecho: la tabla.
  - Si la placa no contesta a `/api/records` (un firmware anterior a 1.2.0): se guardan en la tableta y se dice así.

**Paso 5.5. Ganar**

**Estado:** same
- **Qué se ve:**
  - Las estrellas según los rayos: menos de 10, ⭐; de 10 a 24, ⭐⭐; 25 o más, ⭐⭐⭐. Las que faltan, en gris.
  - «¡Has saltado la Súper Cosechadora!» y «📏 m · ⚡ rayos · ⏱ s».
  - «La siguiente estrella, con N rayos. ¿Te atreves?», o «¡Las tres estrellas! Eres una chispa de verdad.».
- **Qué pasa:**
  - Ganar abre el mundo siguiente («🔓 ¡Nuevo mundo: …!») y da pegatinas: 🚜, y 🐔 o 👽 en los mundos 2 y 3. Se guarda en `juego.mundos`.
  - Cae confeti.
- **Botones:** **↻ ¡Otra vez!**, **«<emoji> Ir a <el mundo siguiente>»** (sólo si lo hay; empieza enseguida) y **☰ Menú**.
- Lleva la misma columna de récords que el fin de partida.

**Paso 5.6. Dos jugadores**

**Estado:** same. La app ya tiene además: con dos jugadores la mano no cuenta (tampoco para agacharse) y la placa no pita. Esto arregla dos huecos que el diseño tenía apuntados. Se mantiene lo de la app.
- **Qué se pulsa:** «👥 2 jugadores» y ▶.
- **Qué se ve:**
  - Pantalla partida: el jugador 1 arriba y el 2 abajo, con los mismos obstáculos.
  - El 2 lleva Menta si el 1 lleva Chispa; si no, lleva Chispa.
  - Los carteles «🔘 Jugador 1: ¡con el botón!» y «👏 Jugador 2: ¡con palmadas!».
  - En la barra, los botones «Jugador 1» y «Jugador 2».
- **Mandos:**
  - **Jugador 1:** salta con FLASH, A o W, su botón, o tocando la mitad de arriba. Se agacha con S, «Agáchate» o la mano entre 15 y 30 cm.
  - **Jugador 2:** salta con una palmada, L o ↑, su botón, o tocando la mitad de abajo. Se agacha con K o ↓.
  - Los mandos de la placa cuentan siempre, aunque estén apagados en «¿Con qué saltas?».
- **Qué pasa:** quien acaba se queda con su cartel mientras el otro sigue.
- **Hecho:**
  - «¡Gana el jugador N!» (🔘🏆 o 👏🏆), o «¡Empate!» (🤝). Gana quien llega más lejos; con los mismos metros, quien tiene más rayos.
  - Las fichas de cada uno dicen sus metros, sus rayos y qué le pilló.
  - **↻ ¡Revancha!** o **☰ Menú**.
  - No hay récords con dos jugadores, pero los rayos de los dos van a la hucha.

**Paso 5.7. La barra de debajo del juego**

**Estado:** same
- **⤴ ¡Salta!** (con dos jugadores, «Jugador 1») y **Jugador 2** (sólo con dos).
- **⤵ Agáchate:** agacha mientras se mantiene pulsado.
- **🔊 Con sonido / 🔇 Sin sonido:** se guarda en `juego.mudo`.
- **⛶ Pantalla completa:** el juego ocupa toda la pantalla; se sale con el mismo botón o con Esc. No sale si el navegador no puede.

**Paso 5.8. Pestaña Jugar (debajo del juego)**

**Estado:** same
1. **«¿Con qué saltas?»**
   - Tres botones que se encienden y se apagan: 🔘 Botón FLASH, 👏 Palmada y 👋 Mano. Se guardan en `juego.mandos`; al principio sólo el botón.
   - La línea de estado dice «🔘 ¡Botón!», «👏 ¡Palmada!» o «👋 ¡Mano!» con cada mando.
   - La señal en directo:
     - «👏 Ruido»: una barra con la raya del rojo del sonómetro.
     - «👋 Mano»: una barra con la raya de 15 cm y la zona morada de 15 a 30 cm.
     - Se mueven aunque ese mando esté apagado.
2. **«Elige tu Chispa»:** Chispa (0 ⚡), Menta (20), Uva (50), Fresa (100) y Hielo (160).
   - «Elegir» la escoge, y pasa a decir «✓ La tuya». Se guarda en `juego.skin`.
   - Las cerradas dicen «🔒 N ⚡». Al tocarlas, el aviso dice «🔒 Uva se abre con 50 rayos. ¡Llevas N!».
   - Debajo: «Llevas **N ⚡** juntados en todas tus partidas. La siguiente, X, con N.», o «¡Las tienes todas!». Se guarda en `juego.rayosTotal`.
3. **«Pegatinas ⭐ N de 9»:** cada una con su dibujo, su nombre y cómo se gana, o «¡Conseguida!».
   - 10 deberes · Noche sin chocar · La Cosechadora · 3 escudos · 50 rayos · 5 brócolis · Agachado · La granja · La luna.
   - Se guardan en `juego.pegatinas`, con las cuentas en `juego.cuentas`.
4. **«🏆 Récords de la clase»:** la tabla y de dónde vienen («guardados en la placa…» o «…se guardan en esta tableta.»).
5. **«Lo que te vas a encontrar · <mundo>»:**
   - Los obstáculos del mundo, más el Nubarrón, el examen volador y la Súper Cosechadora («en 800 m, en 3 fases»).
   - «Lo que te ayuda»: escudo, cohete, cámara lenta y rayos.
- **📱 Móvil (< 860 px):** las tarjetas van una debajo de otra.
- **Estado vacío:** Chispa elegida, 0 ⚡, ninguna pegatina y la tabla de récords vacía.

**Paso 5.9. Programar**

**Estado:** same
- **Bocadillo:** los bloques amarillos «⚡ cuando Chispa…» se ponen en marcha solos cada vez que pasa algo, y puede haber varios a la vez.
- **Bloques:** los comunes, más «esperar a que Chispa…», «si Chispa tiene…» y «⚡ cuando Chispa…».
- **Ejemplo:** dos «⚡ cuando»: verde 0,3 s en cada salto, y rojo con «do» en cada choque.
- **Mientras va un programa:** las luces son del programa; el juego no las toca.
- **Retos (6).**

**Paso 5.10. Montar**

**Estado:** same. La app ya dice «Los récords de la clase los guarda la placa, y duran aunque se desenchufe.»; el diseño todavía dice que hace falta un firmware que los guarde. Se mantiene lo de la app.
- No hay que montar nada nuevo.
- El dibujo (LEDs, micrófono y sensor).
- La tabla de pines: FLASH D3, micrófono A0, sensor D1 y D2, luces D5, D6 y D7.
- El aviso de que guardar los récords en la placa necesita un firmware que lo haga.

---

## 6. Fuera de web/: la página de presentación (sólo prototipo)

**Estado:** no va a `web/`. Está en `design/` y en `preview/`.

**Archivos:**
- `design/Laboratorio - Juegos v4.dc.html`.
- `preview/Laboratorio - Juegos v4 (sin internet).html`: la misma página en un solo archivo, que se abre con doble clic y sin internet.

No es parte de la app de la placa.

- **Qué se ve:**
  - El título «Los 4 juegos del Laboratorio» y cuatro enlaces que bajan a cada juego.
  - Cada juego en un marco, con su panel «La placa» a la derecha.
- **📱 Móvil:** el panel va encima del juego.
- **Los paneles de «La placa»:**
  - **¡Salta, Chispa!:**
    - «🔘 Botón FLASH», «👏 Palmada», «👋 Mano a 8 cm» y «✋ Mano a 22 cm» (mantener para agacharse).
    - «🔓 Abrir mundos y Chispas (para probar)», que pasa a «✓ Mundos y Chispas abiertos».
  - **Duelo de palmadas:** «🗣️ Charla» y «🤫 Silencio» para el ruido de la clase, y «👏 Palmada» (con una fuerza al azar entre 80 y 98).
  - **Caza contrarreloj:** «👻 Viene solo» y «✋ A mano», y el deslizador «📏 Distancia al sensor».
  - **Luz roja, luz verde:** el deslizador «📏 Tu distancia a la placa», y «🚶 Un paso» (15 cm más cerca) y «↩ A la salida» (150 cm).
- **Las luces** de cada panel copian las de su placa de mentira. La línea de estado dice pulsaciones, palmadas, ruido, distancia o energía.
- **Los enlaces de dentro de un juego** a otra página (por ejemplo «detector de fantasmas») bajan a ese juego y abren su pestaña.
