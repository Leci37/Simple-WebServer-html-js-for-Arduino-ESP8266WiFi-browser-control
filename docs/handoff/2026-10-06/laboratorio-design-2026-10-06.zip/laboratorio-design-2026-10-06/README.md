# Laboratorio de inventos · design export (2026-10-06)

| | |
|---|---|
| **Project** | Laboratorio de inventos (ESP8266 / NodeMCU board) |
| **Tool** | none: not a zlecitool tool. It doesn't use zlecitool-core. |
| **Repository** | `Leci37/Simple-WebServer-html-js-for-Arduino-ESP8266WiFi-browser-control`, branch `_ztool_dev` |
| **App it was compared with** | version 1.2.0 (`LAB_VERSION` in `laboratorio/config.h`), as read from GitHub on 2026-10-06 at 14:10 UTC |
| **Where it runs** | on the board itself. The board makes its own wifi and serves `web/`; the pages call its `/api/…` orders. |

## What this export is
The latest design of every page of the web, in `web/`, with the same 15 file names as the repository's `web/` folder. No new files are needed.

Compared with the app today (1.2.0), the design changes four small things and asks for nothing new on the board:
- the Semáforo layout
- two details of the clap duel
- the ghost-hunt clock

The app also has its own fixes made while porting the design, which the design doesn't have. Keep those: see «The app is ahead here» below.

## How to open it (no internet needed)
- **The four games, with a fake board:** double-click `preview/Laboratorio - Juegos v4 (sin internet).html`.
  - It is one self-contained file; no other files or internet needed.
  - Buttons on the right of each game act as the FLASH button, a clap and a hand.
- **Every page, including the home page:** open `preview/lab-v3/index.html`.
  - It is the same web with `simulador.js` added, a fake board that answers `/api` inside the browser.
  - If your browser blocks local files, run `python -m http.server` in this folder and open `http://localhost:8000/preview/lab-v3/`.
- **`web/` on its own:** the pages open, but with no board they show the designed offline state: «Sin conexión» and the «No encuentro la placa…» banner.
  - ¡Salta, Chispa! still plays by touch and keyboard.
  - This is what goes to the board.
- **Design pages (`design/*.dc.html`, `versions/*.dc.html`):** they need the `support.js` next to them, which is included. Serve the folder as above.

## Folders
| Folder | What it is |
|---|---|
| `web/` | **The web, one file per file in the repository's `web/`.** The latest version of every page. No simulator. |
| `preview/` | Ways to try the design offline. Not for the repository. |
| `design/` | The current design pages: the v4 showcase and its packed games, and the 12-ideas page with its pictures. |
| `versions/` | Earlier versions only: the 1.1.0 baseline copy, v2, the earlier showcases, the «Mejoras» page, the earlier export and the review screenshots. |

Also at the root: `README.md` (this file), `FLUJO_USUARIO.md` (the user flow in Spanish, every step marked same / changed / new / removed), `STATUS.md`, `MANIFEST.md` and `texts.json`.

## web/: mapping to the repository
Same 15 names: `index.html`, `inicio.js`, `semaforo.html`, `semaforo.js`, `sonometro.html`, `sonometro.js`, `fantasmas.html`, `fantasmas.js`, `juego.html`, `juego.js`, `bloques.js`, `esquema.js`, `app.css`, `app.js`, `favicon.svg`. No file added, none removed.

**Checked in `web/` on 2026-10-06:**
- nothing loads from the internet: no CDN, no external fonts, no remote images
- no inline `<script>` and no `on…=` attributes
- no `?.`, `??`, arrow functions, `let`/`const`, template strings or classes (`async` only in the block runners, as in the app)
- all five pages have `lang="es"`, a viewport, a `<title>`, `data-conn` and `data-board-name`
- every page and tab fits 360 px

**Differences from the app that are not design changes** (keep the app's version of each):
- The preview line `<script src="simulador.js">` has been taken out of the five pages here. Nothing else in `web/` mentions the simulator.
- Links. The design links pages with `.html` (`semaforo.html`, `index.html`), and its `/api` link is `#`. The app uses the board's addresses: `semaforo`, `href=""` for ←, and `api`.
- The footer's starting text says `1.1.0` here and `1.2.0` in the app. The board fills in the real version anyway.
- `favicon.svg` here still carries about 8 kB of metadata (2.0 kB gzipped); the app's copy has already been cleaned.

## What the design changes (apply these)
| # | Page | File(s) in the app | Change |
|---|---|---|---|
| 1 | Semáforo | `semaforo.html` | «🟢🔴 Luz roja, luz verde» moves from the top of «Jugar» to below the traffic light and «¿Quién manda?», full width. Same content. |
| 2 | Sonómetro | `sonometro.js` | In the clap duel, each turn also counts the board's peak (`sound.peak`), but only a peak that rose after «AHORA» (`duel.peak0` is taken at «AHORA»). Today a short clap between two polls can count low or as 0. |
| 3 | Sonómetro | `sonometro.js` | During a duel, «¡Empezar!» (silence) and «¡Medir!» (clap record) show «Espera a que acabe el duelo 😉» instead of doing nothing. |
| 4 | Detector | `fantasmas.js` | After «¡Tiempo!», the big clock over the ghost stays 4 s with the result, then hides (`#hunt-clock` hidden again unless a new hunt started). Today it stays on «⏱ 0:00». |

**New:** nothing. **Removed:** nothing.

## The app is ahead here (keep the app's version)
These were added while porting the design; the design files don't have them. Don't copy `web/` over the repository.
- **`juego.js`**
  - The world is sent to the board's records in English (`WORLD_API`: `field`, `farm`, `moon`).
  - The records are asked for again at the end of a game, and the toast «Esta vez no entras: mientras jugabas, otros han llegado más lejos» shows if someone got in from another tablet first.
  - Aliases are cleaned like `laboratorio/alias.h` does.
  - With two players the hand doesn't count and the board doesn't beep.
  - The start-screen corners shrink on narrow frames (`fitCorners`, `data-width`).
  - Focus is released when a sign hides, and hidden buttons ignore Enter or Space.
  - The «3 escudos» sticker comes after the power sign.
- **`juego.html`**
  - The corner buttons have `aria-label`s and a `.word` span.
  - The Montar note says the board keeps the class records.
- **`app.css`:** the `[data-width]` rules for those corners.
- **`semaforo.js`:** exactly 40 cm is refused too (`<= 40`), and Chispa keeps cheering until the light goes back to automatic (`BACK_TO_AUTO_MS`).
- **`sonometro.js`:** the winner's blinking stops if a rematch starts.
- **`bloques.js`:** a «⚡ cuando…» dropped inside another block goes to the top level, and when one branch fails or stops, all of them stop and finish before the next ▶.

## /api calls
**New: none. Changed: none.** The design uses only orders the 1.2.0 firmware already has (`laboratorio/web_api.h`), with the same parameters.

| Page | Calls the design makes |
|---|---|
| Home (`inicio.js`, `app.js`) | `GET /api/state` (every 1.5 s) |
| Semáforo | `/api/state` (350 ms; 150 ms during «Luz roja, luz verde») · `/api/mode?set=manual|auto|night` · `/api/light?color=red|yellow|green|all&on=0|1` · `/api/walk` · `/api/settings?trafficSpeed=1|2|3` · `/api/beep?hz=330&ms=200` and `?hz=196&ms=400` |
| Sonómetro | `/api/state` (250 ms; 100 ms during the duel) · `/api/mode?set=sound` · `/api/settings?soundYellow=&soundRed=&soundGain=&soundAlarm=` · `/api/light` (duel: leader's colour, winner blinking) |
| Detector | `/api/state` (250 ms) · `/api/mode?set=ghost` · `/api/settings?ghostNear=&ghostFar=&ghostSound=` |
| ¡Salta, Chispa! | `/api/state` (2.5 s) · `/api/input` (every ~70 ms) · `/api/light` and `/api/beep` (game lights) · `/api/records` · `/api/record?alias=&m=&t=&w=` |
| Block editor (every page) | `/api/light`, `/api/beep`, `/api/state` |

One difference, where the app is ahead: in `/api/record` the design still sends `w=campo|granja|luna`, while the app and the firmware use `w=field|farm|moon`. Keep the app's. Design change 2 reads `sound.peak` from `/api/state`, which the board already sends.

## Size of the web (gzipped)
Measured like the 85.7 kB figure: each file gzipped on its own, added up, with 1 kB = 1024 bytes. The app's 15 files measure 85.76 kB this way.

| | gzipped | vs 85.7 kB |
|---|---|---|
| App today (1.2.0, `_ztool_dev`) | 85.8 kB | — |
| App today plus the 4 design changes | **≈ 86.0 kB** | **+0.2 kB (+0.2 %)** |
| `web/` of this zip, as it is | 86.4 kB | +0.7 kB. That includes the uncleaned favicon (+2.0 kB) and lacks the app's own later code. |

The board's flash is at 37 %; 0.2 kB more doesn't change that in any noticeable way. Load time doesn't change either: the same files, the same number of requests.

## Pages
| Page | File in web/ | States | Status |
|---|---|---|---|
| Home | `index.html`, `inicio.js` | loading, error (no board), done | final |
| Semáforo · Jugar | `semaforo.html`, `semaforo.js` | loading, error, done; «Luz roja, luz verde»: ready, green, yellow, red, caught, arrived, stopped | final (change 1) |
| Sonómetro · Jugar | `sonometro.html`, `sonometro.js` | loading, error (no mic), done; duel: idle, countdown, NOW, between turns, round result, winner or tie | final (changes 2 and 3) |
| Detector · Jugar | `fantasmas.html`, `fantasmas.js` | loading, error (no echo), done; levels 0–5; hunt: idle, running, last 10 s, time's up | final (change 4) |
| ¡Salta, Chispa! | `juego.html`, `juego.js` | start, playing (1 or 2 players, boss phases), game over (with or without the alias form), win (1–3 stars), two-player result | in progress: the star thresholds (10 and 25 bolts) are still placeholders |
| Programar (every page) | `bloques.js` | empty, running, error, done | final |
| Montar (every page) | `esquema.js` | — | final |
| Shared | `app.css`, `app.js`, `favicon.svg` | — | final |

## Design tokens in use (`web/app.css`)
### Colours: `:root`
| Token | Value | Use |
|---|---|---|
| `--bg` | `#fff6e6` | page background |
| `--dots` | `#ffe1b3` | dotted background pattern |
| `--ink` | `#23214a` | text |
| `--muted` | `#625f8a` | secondary text |
| `--card` | `#ffffff` | cards |
| `--line` | `#efe4cf` | card borders |
| `--shadow` | `rgba(35,33,74,0.1)` | solid drop shadows |
| `--accent` / `--accent-dark` / `--accent-soft` | `#1fa463` / `#127a46` / `#dcf7e8` | buttons and focus (Semáforo green) |
| `--red` / `--yellow` / `--green` | `#ff4f4f` / `#ffc83d` / `#22d47b` | lamps on |
| `--lamp-off` | `#3b3d55` | lamps off |
| `--cat-luces` / `-dark` | `#9966ff` / `#774dcb` | block category: lights |
| `--cat-sonido` / `-dark` | `#cf63cf` / `#a63fa6` | block category: sound |
| `--cat-control` / `-dark` | `#ffab19` / `#cf8b17` | block category: control |
| `--cat-sensores` / `-dark` | `#4cb2dc` / `#2b8cb6` | block category: sensors |
| `--cat-eventos` / `-dark` | `#ffbf00` / `#cc9900` | block category: events (hats) |
| `--radius` | `24px` | card radius |

### Colours: themes
| Theme | Overrides |
|---|---|
| `.theme-sound` | `--bg #f6f0ff`, `--dots #e6d9ff`, `--line #e7dcfb`, `--accent #8b5cf6`, `--accent-dark #6a3bd8`, `--accent-soft #efe7ff` |
| `.theme-ghost` | `--bg #17123a`, `--dots #2a2161`, `--ink #f4f0ff`, `--muted #b9b1e6`, `--card #241c55`, `--line #3a2f7a`, `--shadow rgba(0,0,0,0.35)`, `--accent #3ff0b0`, `--accent-dark #17b07c`, `--accent-soft #1d4b52` |
| `.theme-game` | `--bg #fff3e6`, `--dots #ffd9b3`, `--accent #f97316`, `--accent-dark #c2410c`, `--accent-soft #ffedd5` |
| `.theme-traffic` and `.home` | the `:root` values |

### Other colours
- **Most used literals:**
  - `#fff`
  - `#ffd84d` (Chispa)
  - `#2b2d42` and `#1b1c2c` (traffic-light housing)
  - `#22c063` / `#158a45` (go button)
  - `#ff5a5a` / `#c43535` (stop button)
  - `#ff9f1c` (pedestrian button)
  - `#fbfaff` (script area)
- **Canvas worlds** (`juego.js`, day / evening / night):
  - Campo: far `#a9c7ff` `#d99ab0` `#2b2470`, near `#7cd36b` `#b8b25e` `#24584a`
  - Granja: far `#b8d9a0` `#e7a487` `#2b2470`, near `#efcf63` `#e2a64f` `#3d4a3a`
  - Luna: `#4b4685`, `#7d7a9e`, `#a6a4bb`, `#c9c7da`
- **Chispa colours:** `#ffd84d`, `#6fe3a6`, `#c4a3ff`, `#ff9fc2`, `#9fe6ff`.

### Fonts
- **Main stack:** `ui-rounded, "SF Pro Rounded", "Nunito", "Varela Round", "Segoe UI Rounded", "Arial Rounded MT Bold", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif`. System fonts only; nothing downloaded.
- **Code:** `ui-monospace, Menlo, Consolas, monospace`.
- **Weights:** 600, 700, 800 and 900.
- **Base size:** 17px.
- **Font sizes:** from 0.72rem to 3rem; the most used is 0.85rem. h1 is 2.6rem from 720 px; the top-bar title is 1.15rem below 480 px.
- **Line heights:** 1 to 1.45.

### Spacing, radii, borders, shadows
- **Gaps:** 2, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20 and 22 px.
- **Common paddings:** `4px 12px`, `6px 12px`, `10px 14px`, `12px 16px`, `14px 20px`, `20px`; page gutter 16 px.
- **Radii:** `999px` (pills and buttons), `50%` (lamps), `24px` (cards), plus 22, 20, 18, 16, 14, 12, 10, 8, 7, 6, 5 and 2 px. Block hats are `28px 28px 10px 10px`.
- **Borders:** 3px solid for most; also 2, 4, 6 and 9 px.
- **Shadows:**
  - Solid offset shadows with no blur: `0 Npx 0 var(--shadow)`, with N = 1, 2, 4, 5, 6 or 8.
  - Pressed buttons go from 6px to 2px and move down 4px.
  - Lamps and buttons use `inset 0 -6px 0 rgba(0,0,0,0.25)`.
- **Breakpoints:** 480, 520, 600 (portrait), 640, 720, 760, 860, 899/900 and 1000 px, plus `prefers-reduced-motion`.

### What belongs to whom
Nothing comes from zlecitool-core. Everything is the Laboratorio's own:
- **Top bar:** ← back, title and connection pill.
- **Footer:** version and board name.
- **Home page:** hero with Chispa and four cards.
- **Buttons:** `.btn`, `.btn-soft`, `.btn-go`, `.btn-stop`.
- **Colours and fonts:** the tokens above.
- **Not in the Laboratorio:** welcome tour, carousel, account, credits and cookie banner. There are no cookies; it only uses `localStorage` with the prefix `lab.`.

## Prompt for Claude Code
> Work in `Leci37/Simple-WebServer-html-js-for-Arduino-ESP8266WiFi-browser-control`, on branch `_ztool_dev`. Do not create `design/` branches and do not open pull requests.
>
> 1. Save this zip, exactly as it is, in `docs/handoff/2026-10-06/laboratorio-design-2026-10-06.zip`.
> 2. Read `README.md`, `FLUJO_USUARIO.md` and `STATUS.md` from the zip.
> 3. Compare the zip's `web/` and `FLUJO_USUARIO.md` with the repository's `web/`. The repository has no `docs/FLUJO_USUARIO.md` yet; if it has one by now, compare it too. Write `CAMBIOS.md` with every difference, each marked "tool". The Laboratorio doesn't use a shared core.
> 4. Apply only the four changes in «What the design changes». Don't copy the zip's `web/` over the repository: the app has fixes the design doesn't (see «The app is ahead here»), and the mapping notes (links, version, favicon) must stay as they are in the app.
> 5. Don't add `simulador.js` or anything from `preview/`, `design/` or `versions/` to `web/`.
> 6. Keep the board's rules:
>    - nothing from the internet
>    - no inline JavaScript and no `on…=` attributes
>    - `var` and `function`, with no `?.` or `??`
>    - Spanish texts for kids, informal («tú»)
>    - 360 px
>    - `data-conn` and `data-board-name` on every page
> 7. Run `python tools/build_web.py` (never edit `laboratorio/web_pages.h` by hand), run `pytest` and check the firmware still compiles.
> 8. Report the gzipped size of `web/` against 85.7 kB. The estimate is about 86.0 kB.
