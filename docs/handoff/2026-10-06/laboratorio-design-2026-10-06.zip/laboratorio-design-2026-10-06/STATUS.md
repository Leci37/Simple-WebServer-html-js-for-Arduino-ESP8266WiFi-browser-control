# STATUS · Laboratorio de inventos design export

Export date: 2026-10-06. Compared with the app 1.2.0 on `_ztool_dev`, as read from GitHub on 2026-10-06 at 14:10 UTC.

What each status means:
- **final:** settled; nothing in the design is waiting.
- **in progress:** built, but a decision is still open.
- **sketch:** drawn, with no working logic.

## Pages of the web (`web/`)

| Page | Files | Status | Design vs app today | Still open |
|---|---|---|---|---|
| Home | `index.html`, `inicio.js` | final | same | — |
| Semáforo, with «Luz roja, luz verde» | `semaforo.html`, `semaforo.js` | final | changed: the game card moves below the traffic light | The app's later fixes (40 cm exactly, Chispa cheering) aren't in the design; keep the app's. |
| Sonómetro, with the clap duel | `sonometro.html`, `sonometro.js` | final | changed: the duel also counts the peak; silence and clap buttons warn during a duel | The app's «stop blinking on rematch» isn't in the design; keep the app's. |
| Detector, with the one-minute hunt | `fantasmas.html`, `fantasmas.js` | final | changed: the clock hides 4 s after the end | — |
| ¡Salta, Chispa! | `juego.html`, `juego.js` | in progress | same | The win-star thresholds (10 and 25 bolts) are placeholders, in the design and in the app. The app is ahead in several places (see README). |
| Programar: block editor | `bloques.js` | final | same | The app is ahead: hats dropped inside a block, stopping all branches. |
| Montar: wiring | `esquema.js` | final | same | — |
| Shared | `app.css`, `app.js`, `favicon.svg` | final | same | The app is ahead: `[data-width]` rules and a cleaned favicon. |

## Design pages (not part of `web/`)

| Page | File | Status |
|---|---|---|
| The 4 games, offline single file | `preview/Laboratorio - Juegos v4 (sin internet).html` | final (prototype only) |
| The 4 games, source | `design/Laboratorio - Juegos v4.dc.html` + `design/lab-v4/paginas.js` | final (prototype only) |
| Every page with the fake board | `preview/lab-v3/` | final (prototype only; same as `web/` plus `simulador.js`) |
| The 12 ideas | `design/Juegos - Ideas.dc.html` | final as a proposal; all 12 are in the app |
| Improvements before/after | `versions/Juegos - Mejoras.dc.html` | outdated. Items 1–5 are done. Items 6 (big silence screen with the day's top 3 claps) and 7 (ghost album) are **sketches**, never built. |
| Earlier showcases | `versions/Laboratorio - Juegos.dc.html`, `… v2.dc.html`, `… v3.dc.html` | superseded |

## Sample data that is not real
- **The fake board (`simulador.js`, in `preview/` only):**
  - It calls itself «Laboratorio-SIM» at 192.168.4.1, version 1.1.0.
  - It starts the class records with four sample aliases (Rayo 906 m, Tortuga 640 m, Chispi 512 m, Pulga 330 m).
  - Its noise and distance are made-up waves.
- **The showcase's «La placa» panels:** each clap has a random strength between 80 and 98.
- **The «Ideas» and «Mejoras» pages:** team names, aliases and numbers are examples.
- **Pictures:** every picture in `design/img/`, `versions/img/` and `versions/shots/` comes from the fake board.

## Open questions
1. What should the win-star thresholds be? Today: 10 and 25 bolts.
2. Should «Mejoras» items 6 and 7 (sketches) be built?
3. Should the design files be brought up to the app's later fixes, so the next export starts from the app? This export left every page exactly as designed.
