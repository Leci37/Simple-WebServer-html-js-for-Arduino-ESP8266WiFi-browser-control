# Laboratorio de inventos · user flow (v3)

What a child, teacher or family member can do, screen by screen, from the welcome screen on. For every click, toggle and slider it says what the app must do. UI text is quoted exactly as it appears (Spanish).

- **Version described:** `lab-v3/`, the one to be ported into `web/`.
- **Board vs simulator:** "the board" means the NodeMCU answering `/api/...`. In the prototype, `simulador.js` answers instead; behaviour is the same unless a note says otherwise.
- **Saved:** stored in the browser's `localStorage` under `lab.<key>`. It survives reloads, on that device only.
- **Board call:** an HTTP request to the board, e.g. `/api/light?color=red&on=1`. Every call answers with the full board state, which repaints the page.

---

## 1. What every page shares

### 1.1 Top bar
| Element | Click / state | Expected result |
|---|---|---|
| **←** (round, left) | Click | Goes to the home page (`index.html`). Not shown on the home page. |
| Title | — | 🚦 Semáforo · 🎤 Sonómetro · 👻 Detector de fantasmas («de fantasmas» is hidden on small screens) · 🎮 ¡Salta, Chispa! |
| Connection pill (`data-conn`) | Automatic | Starts as «Conectando…». Turns into **«Conectado»** (green) after the first board answer. After **2 failed polls in a row** it turns into **«Sin conexión»** and the page gets `is-offline`. |

### 1.2 Offline banner
Only while offline: «No encuentro la placa. ¿Está enchufada? ¿Sigues conectado a su wifi (**Laboratorio-…**)?» The name comes from the board once it has answered at least once.

### 1.3 Footer
«Laboratorio de inventos · versión **1.1.0** · placa **…**». The version and board name are filled in from the board.

### 1.4 Polling
Each page asks the board for its state on a timer:
- Home: every 1.5 s
- Semáforo: every 350 ms (150 ms during «Luz roja, luz verde»)
- Sonómetro: every 250 ms (100 ms during the duel)
- Fantasmas: every 250 ms
- ¡Salta, Chispa!: every 2.5 s, plus `/api/input` about every 70 ms

With the tab hidden, the state poll slows to every 2 s (the `/api/input` poll to every 1 s).

### 1.5 Tabs: 🎮 Jugar · 🧩 Programar · 🔌 Montar
On the three inventions and the game.
| Action | Result |
|---|---|
| Click a tab | Shows its panel and hides the other two. The address changes to `#jugar`, `#programar` or `#montar`. |
| ← / → on a focused tab | Moves to the previous or next tab (wraps around). |
| Opening a link with `#programar` (or `#montar`) | The page opens on that tab. Links in «Paso a paso» use it (e.g. `semaforo.html#montar`). |
| No hash | Opens on **Jugar**. |

### 1.6 Chispa, the helper
A lightbulb with a speech bubble at the top of each tab. The bubble (`data-say`) and Chispa's face (happy, wow or scared) change with what is going on. Each page lists its texts below.

### 1.7 Toasts and confetti
- A toast is a short message at the bottom, on screen for 2.6 s. A new toast replaces the old one.
- Confetti is 22 falling pieces (🎉 ⭐ ✨ 🎊 💛 🌟), gone after about 2.4 s.

### 1.8 🏆 Retos (Programar tab)
- Each reto is a toggle button. The child marks it themselves; the app never checks it.
- Click an unmarked reto: it shows ✓, confetti falls, and the toast says «¡Reto conseguido! 🏆».
- Click a marked reto: it is unmarked, with no celebration.
- The heading counter shows «⭐ N de M».
- Saved: `retos.semaforo`, `retos.sonometro`, `retos.fantasmas`, `retos.juego`.

### 1.9 Block editor (Programar tab, all four pages)
**Layout.** A palette on the left (on top on phones), grouped by category: 💡 Luces, 🔊 Sonido, 🔁 Control, 📡 Sensores, plus ⚡ Eventos in the game only. On narrow screens the palette shows one category at a time, with category tabs. The script area on the right always starts with the hat «🏁 al pulsar ▶ ¡Ejecutar!».

**Building the program**
| Action | Result |
|---|---|
| Drag a block from the palette into the script | It drops where you let go: in the main stack, or inside a «repetir» / «por siempre» / «si…» / «⚡ cuando…». |
| Tap a palette block (no drag) | It is added to the **target**: the bottom of the main stack, or inside the C-block whose slot you tapped last (that slot is highlighted). |
| Tap the empty slot of a C-block | That block becomes the target. |
| Drag a block out of the script | While dragging, «🗑️ Suelta fuera para quitarlo» shows. Dropping outside removes it, with the toast «Bloque quitado 🗑️». |
| **×** on a block | Removes the block, and everything inside it. |
| Number field | Type a number (a comma is fine, e.g. 0,5). On leaving the field it is clamped to that block's limits. |
| Dropdown (colour, note, comparison, event, power) | The value is kept as soon as it is picked. |
| «⚡ cuando Chispa…» blocks | Always go in the main program, never nested. |

The program is saved after every change (`programa.<page>`) and comes back after a reload.

**Toolbar**
| Button | Expected result |
|---|---|
| **▶ ¡Ejecutar!** | With no blocks: toast «Primero pon algún bloque 😉». Otherwise it runs the program on the board: the status says «▶ Ejecutando…», the running block is highlighted, and loops show their lap («2 de 3», «vuelta 4», «3 veces»). Hat blocks wait for their events while the main stack runs. ▶ is disabled while running. |
| **■ Parar** | Stops everything. Status «■ Parado.» Some pages also give the lights back to the invention (see each page). |
| **💡 Ejemplo** | If there are blocks, it first asks «¿Cambiar tu programa por el ejemplo?». Accepting loads that page's example, and the status shows the example's text. |
| **🧹 Borrar** | If there are blocks, it asks «¿Borrar todos los bloques?». Accepting empties the program. |
| Any edit while running | Blocked, with the toast «Para el programa (■) para cambiar los bloques». |

How a run ends:
- Normal end: «✓ ¡Terminado! ¿Lo cambias y lo pruebas otra vez?»
- Board error: «😕 <message>. ¿Sigues conectado a la placa?», and the program stops.
- A program with «por siempre» or a «⚡ cuando…» only ends with ■.

**Blocks (labels as shown)**
- **Luces:** «encender [rojo / amarillo / verde]», «apagar [color]», «apagar todas»
- **Sonido:** «pitar [0,2] segundos» (0,05–5), «tocar [nota] durante [0,5] s»
- **Control:** «esperar [1] segundos» (0,1–60), «repetir [3] veces» (1–100), «por siempre»
- **Sensores**, which depend on the page:
  - Semáforo: «esperar a que pulsen el botón 🔘»
  - Sonómetro: «esperar a que el ruido sea [mayor/menor] que [60]», «si el ruido es [mayor/menor] que [60]»
  - Fantasmas: «esperar a que algo esté a menos de [30] cm», «si algo está a menos de [30] cm»
  - ¡Salta, Chispa!: «esperar a que Chispa [evento]», «si Chispa tiene [🚀 el cohete / 🛡️ el escudo / ⏱️ la cámara lenta]»
- **Eventos** (game only): «⚡ cuando Chispa [salte / choque / coja un rayo / coja un poder / pierda / gane / se agache / pase de fase]»

---

## 2. Home page (`index.html`): the welcome screen

### 2.1 What the user sees, top to bottom
1. **Hero:** Chispa (happy), «¡Hola! Soy Chispa 👋», the title «Laboratorio de inventos», «Una placa, tres inventos, un juego y muchas ideas. ¿Por cuál empiezas?» and the connection pill.
2. **Offline banner**, only when there is no board (1.2).
3. **Four invention cards.** The whole card is one link.

| Card | Level | Says | Needs | Button label | Opens |
|---|---|---|---|---|---|
| Semáforo | ⭐ Para empezar | «Enciende las luces, ponlo en automático y programa tu propia secuencia.» | 3 LEDs y 3 resistencias | ¡Vamos! | `semaforo.html` |
| Sonómetro | ⭐⭐ Un poco más | «¿Cuánto ruido hay? Las luces del semáforo te lo dicen. ¿Aguantáis en verde?» | el semáforo y un micrófono | ¡Vamos! | `sonometro.html` |
| Detector de fantasmas | ⭐⭐⭐ Para valientes | «Un radar que avisa cuando algo se acerca… ¿o es alguien?» | el semáforo y un sensor de distancia | ¡Vamos! | `fantasmas.html` |
| ¡Salta, Chispa! | 🎮 Para jugar | «Corre y salta como el dinosaurio de Chrome… pero con el botón de la placa, una palmada o la mano.» | la placa (y, si quieres, el micrófono o el sensor) | ¡A jugar! | `juego.html` |

4. **«¿Cómo se juega?»** (static): 🔌 Monta · 🎮 Juega · 🧩 Programa.
5. **«Para profes y familias»** (static): the programming idea behind each invention, the board's wifi name, the address `http://192.168.4.1`, and a link to the list of `/api` orders. On the board, that link opens the JSON list. In the prototype copy it is `#` and does nothing.
6. Footer.

### 2.2 Behaviour
- The home page only reads the board state every 1.5 s, to fill in the pill, the board name and the version. It never changes the board's mode.
- Clicking a card opens that page on its **Jugar** tab, with everything saved before (records, programs, settings).

---

## 3. 🚦 Semáforo (`semaforo.html`)

**On opening:** if the board's lights belong to the Sonómetro or the Detector (mode `sound` or `ghost`), the page switches the board to **Automático**.

### 3.1 Jugar tab, top to bottom

**Bubble** (follows the board's mode; it doesn't change while a block program or «Luz roja, luz verde» is running):
| Board state | Text |
|---|---|
| Automático, pedestrians crossing | «¡Rojo para los coches: ya pueden cruzar los peatones! 🚶» |
| Automático | «Automático: verde, amarillo, rojo… ¿Quieres cruzar? ¡Pulsa el botón!» |
| Noche | «Modo noche: el amarillo parpadea. Quiere decir «¡cuidado!».» |
| Yo (manual) | «Tú mandas: toca las luces para encenderlas y apagarlas.» |
| Another invention has the lights | «Las luces las tiene otro invento. Elige un modo para recuperarlas.» |

**Card 1, the traffic light**
| Element | Action | Expected result |
|---|---|---|
| Red, yellow and green lamps (buttons) | Click | The board switches to **Yo** (manual). If that lamp was already on in manual, it turns off; otherwise it turns on. The real LED does the same. The lamp's `aria-pressed` follows the board. |
| Pedestrian light (red / green figure) | — | Green figure while cars have red in Automático, or while the red lamp is on in Yo. Red figure otherwise. Both off in Noche. |
| **🔘 Quiero cruzar** | Click | In Automático: the board's pedestrian button. Green ends early (after at least 1 s), then yellow, then red with the pedestrian green. In any other mode: toast «El botón de peatones funciona en automático 🔄». |
| Board FLASH button | Press | Same as «Quiero cruzar» in Automático. |

**Card 2, «¿Quién manda?»**
| Control | Result |
|---|---|
| 🖐️ Yo · 🔄 Automático · 🌙 Noche | Sets the board's mode. The active one is highlighted. |
| «Velocidad del automático»: 🐢 Tortuga · 🚶 Normal · 🐇 Liebre | Only visible in Automático. Saves `trafficSpeed` 1, 2 or 3 on the board. The simulator then uses green/yellow/red of 8/3/8 s, 5/2/5 s or 3/1/3 s. |
| Tip | Static: the FLASH button is also the pedestrian button. |

**Card 3, «🟢🔴 Luz roja, luz verde» (idea 12; full width, below the traffic light)**
- **Start: ¡Empezar!**
  - No echo from the distance sensor: toast «📏 No te veo: ponte delante del sensor de distancia». Nothing starts.
  - Closer than 40 cm: toast «📏 Aléjate un poco: a más de 40 cm de la placa». Nothing starts.
  - Otherwise the game starts. Your current distance becomes the **start line**, the button turns into «■ Parar», and polling speeds up to 150 ms.
- **The cycle** (the board's lights follow it; the box above the track shows the phase):
  1. **🟢 ¡Avanza!** for 2–4.5 s at random. Bubble: «¡Verde! Avanza hacia la placa… 🚶».
  2. **🟡 ¡Atento!** for 0.8 s.
  3. **🔴 ¡Quieto!** for 2–3.5 s at random, with a short beep (330 Hz). Bubble: «¡Rojo! Ni un pelo… 👀». You get 0.45 s to stop. After that, a change of more than **6 cm** catches you.
  4. **Caught:** «👀 ¡Te he visto! Vuelve a la salida (N cm)», a low beep (196 Hz) and the bubble «¡Te he visto moverte! A la salida…» (scared face). Once you're back within 10 cm of the start line, it goes green again.
  5. Then back to green, and so on.
- **Track:** 🚶 moves from «Salida» to 🏁 as you get closer. The middle label shows «📏 N cm».
- **Win:** reaching **12 cm or less** (in any phase except while caught):
  - «🏁 ¡Has llegado en X,Y s!», plus « 🏆 Récord» if it is the best time and «· te pilló N vez / veces» if you were caught.
  - Green light, confetti, bubble «¡Has llegado a la placa! 🏁», and the button says «¡Otra vez!».
- **■ Parar** during the game: «Parado. Cuando quieras, ¡otra vez!» and the button says «¡Otra vez!».
- **Afterwards:** 2.5 s after the game ends (by winning or stopping), the traffic light goes back to Automático.
- **Record:** the lowest time, shown with a comma (e.g. «12,4 s»). Saved: `semaforo.luzroja`.

### 3.2 Programar tab
- **Bubble:** «Pon bloques en orden para hacer tu secuencia de luces y pulsa ▶ ¡Ejecutar! El semáforo de verdad hará lo mismo, paso a paso.»
- **Blocks:** Luces, Sonido, Control, plus «esperar a que pulsen el botón 🔘».
- **Example** («El semáforo de siempre, 3 veces. ¿Te atreves a hacerlo más rápido?»): repetir 3 × (verde 3 s, amarillo 1 s, rojo 3 s).
- **Retos (5):** three lights on and off · the traffic sequence with «esperar» · repeat it 5 times with «repetir» · a broken light, yellow blinking forever · a pedestrian crossing (wait for the button, red, beep).

### 3.3 Montar tab
Static:
- **«Lo que necesitas»** (6 items, including the distance sensor for «Luz roja, luz verde»)
- **«Cómo se conecta»** (wiring drawing: LEDs and buzzer highlighted, mic and sensor dimmed; pins table D5/D6/D7/GND/D8/D3)
- **«Paso a paso»** (6 steps) and a tip about resistors

---

## 4. 🎤 Sonómetro (`sonometro.html`)

**On opening:** the board switches to mode **sound**, so its lights show the noise level while the page is open.

### 4.1 Jugar tab
**Bubble and face** (only change when the mood changes, and not while a program runs):
| Noise level (0–100) | Face · label | Bubble |
|---|---|---|
| ≥ red threshold | 🙉 «¡Demasiado ruido!» | «¡Uf, qué jaleo! ¡Me tapo los oídos!» |
| ≥ yellow threshold | 😮 «¡Cuánto jaleo!» | «Eso ya es bastante ruido… ¡amarillo!» |
| ≥ half of yellow | 🙂 «Ruido tranquilo» | «Se oye algo, pero tranquilo: verde.» |
| below that | 🤫 «Silencio» | «Shhh… qué silencio. ¡Da una palmada a ver qué pasa!» |

**«No oigo nada…» tip:** shown when the board says there is no microphone.

**Gauge card**
- Needle from 0 to 100, with green, yellow and red zones drawn from the current settings.
- The peak marker holds the loudest level for 2 s.
- Number and label in the middle.
- A small traffic light copies the board's LEDs.

**«Los últimos 30 segundos»:** a chart of the noise, coloured by zone, with dashed lines at the yellow and red thresholds.

**Card «Juegos»**
| Game | Steps | Expected result |
|---|---|---|
| 🤫 **Reto del silencio** · ¡Empezar! | Click | The button is disabled during the game. The text counts «3…», «2…», «1…» (0.8 s each), then «¡Silencio! 🤫», and a bar fills over 10 s. |
| | Noise reaches yellow | The game stops: «¡Uy! Se oyó algo (N). ¿Otra vez?» |
| | 10 s without reaching yellow | «¡Conseguido! Diez segundos en verde. 🏆», confetti and the toast «¡10 segundos de silencio! 🏆». The button says «¡Otra vez!». |
| 👏 **Récord de palmada** · ¡Medir! | Click | The button is disabled, and the text says «¡Ahora! ¡Una palmada fuerte! 👏». It listens for 3 s and keeps the loudest level or peak. |
| | New best | «¡Nuevo récord! **N** 🎉» and confetti. Saved: `sonometro.record`. |
| | Not a record | «Tu palmada: **N**. Récord: **M**» |
| Either game during the duel | Click | Toast «Espera a que acabe el duelo 😉». |

**Card «⚔️ Duelo de palmadas» (idea 10)**
1. **¡Empezar el duelo!**
   - If the silence or clap game is running: toast «Espera a que acabe el otro juego 😉».
   - Otherwise the button is disabled, polling speeds up to 100 ms and the board shows yellow.
2. **Each turn** (red first, then green):
   - A countdown «Ronda N de 3 · Equipo rojo, preparados… 3 / 2 / 1», 0.7 s per number. The current team's tile is highlighted.
   - Then «¡Equipo rojo, **AHORA**! 👏»: 2.5 s, with a bar filling up. The tile shows «¡Ahora! N» with the loudest so far.
   - Both the level and the peak count, but only a peak that rose after «AHORA».
3. **After red:** «🔴 El rojo ha hecho **N**. Ahora, el verde…», then green's turn about 1.4 s later.
4. **After green, the round is decided:**
   - «Ronda N para el **rojo**, X a Y», or the same for verde. The winner gets 1 point.
   - Same value: «Ronda N: ¡empate a X!», and nobody scores.
   - The board's light shows who leads: red, green, or yellow when tied.
   - Each tile lists its claps: «Palmadas: 92 · 85».
5. **End** (when a team has 2 points, or after round 3):
   - Winner: «🏆 ¡Gana el equipo **rojo**, 2 a 0!», confetti and the toast «¡Gana el equipo rojo! 🏆». The winner's LED blinks 4 times.
   - Tie: «🤝 ¡Empate, 1 a 1! ¿La revancha?»
   - The button says «¡La revancha!». About 1.6 s later the lights go back to showing the noise (mode `sound`).

**Card «Ajustes»**
| Control | Range | Behaviour |
|---|---|---|
| 🟡 «Amarillo a partir de» (slider) | 5–95 | While dragging, yellow stays below red: if they meet, the other slider is pushed by 1. Sent to the board on release. |
| 🔴 «Rojo a partir de» (slider) | 10–100 | Same rule. The gauge zones, chart lines, game thresholds and the clap that makes Chispa jump in the game all follow it. |
| 🎚️ «Sensibilidad del micrófono» | 25–400 %, steps of 25 | Sent on release. |
| 🔔 «Pitar si hay demasiado ruido» (switch / checkbox) | on / off | Sent at once. With it on, the board beeps when the noise reaches red. |

While a slider is being dragged, values coming from the board don't overwrite it. A board error shows the toast «😕 <message>».

### 4.2 Programar tab
- **Bubble:** about the blue blocks that listen («esperar a que el ruido sea mayor que…»).
- **Blocks:** Luces, Sonido, Control, plus «esperar a que el ruido sea…» and «si el ruido es…».
- **Example** («La alarma de jaleo…»): forever, green until the noise goes over 70, then red, the note «la» and 2 s.
- **■ Parar or the program ending:** the board goes back to mode `sound`.
- **Retos (6):** silence 10 s · clap to 90 · program an alarm · tune the colours for the class · your own meter with «si» blocks · win the duel.

### 4.3 Montar tab
Static: parts, wiring (mic and LEDs), pins A0/3V3/GND, five steps and a tip about the KY-038 screw.

---

## 5. 👻 Detector de fantasmas (`fantasmas.html`)

**On opening:** the board switches to mode **ghost**, so its lights warn about ghosts while the page is open.

### 5.1 Jugar tab
**Levels** (energy 0–5, worked out from the distance and the two settings):
| Level | When | Status · bubble |
|---|---|---|
| 0 | no echo, or farther than «amarillo» | «Todo tranquilo… 😴» · «Todo tranquilo. Apunta el sensor a la puerta y espera…» |
| 1 | inside «amarillo», far | «Algo se mueve a lo lejos… 👀» |
| 2 | inside «amarillo», nearer | «Se acerca algo… 👀» |
| 3 | inside «amarillo», close | «¡Está cerca! 😨» (scared) |
| 4 | inside «rojo» | «¡Fantasma cerca! 😱» |
| 5 | at half of «rojo» or closer | «¡¡ESPECTRO DETECTADO!! 👻» · «¡¡BUUU!! ¡Foto, foto! 📸» |

**Radar card**
- The ghost blip sits at the measured distance, with dashed rings at «amarillo» and «rojo» (labelled in cm).
- The readout shows «N cm» (or «—»), the status line and the 5 «Energía espectral» bars.

**Ghost card**
- The big ghost becomes more visible and larger as the level rises. At level 5, «¡BUUU!» appears.
- **Catching:** each time the level reaches 5 from below (at most once every 2 s):
  - The screen flashes white.
  - «📸 Fantasmas cazados» goes up by 1. Saved: `fantasmas.cazados`.
  - Toast «📸 ¡Fantasma cazado! Ya llevas N.»
- **Empezar de cero:** resets the count to 0.

**«⏱ Caza contrarreloj» · ¡Un minuto! (idea 11)**
1. **Start:** the button is disabled. A big clock appears over the ghost («⏱ 1:00 · 👻 0 cazados») and the text says «¡A cazar! Lleva el detector hasta el 5, una y otra vez.»
2. **During the minute:** each catch adds to the clock's score, with the toast «📸 ¡Uno más! Llevas N en este minuto.» In the last 10 s the clock turns urgent.
3. **At 0:00:**
   - «¡Tiempo! N fantasmas en un minuto.» (plus « 🏆 ¡Récord nuevo!» when it beats the record) and the toast «⏱ ¡Tiempo! N cazados». Confetti on a record.
   - The button says «¡Otra vez!». The clock stays 4 s with the result, then hides.
   - The record is the most catches in a minute. Saved: `fantasmas.contrarreloj`.

**Board lights legend:** «verde, nada; amarillo, algo se acerca; rojo, ¡fantasma!»

**Card «Ajustes»**
| Control | Range | Behaviour |
|---|---|---|
| 🔴 «Rojo si está a menos de» | 5–100 cm | «Rojo» always stays at least 5 cm below «amarillo»; the other slider is pushed if needed. Sent on release. |
| 🟡 «Amarillo si está a menos de» | 15–300 cm, steps of 5 | Same rule. The radar scale grows with it. |
| 🔊 «Pitidos de radar en la placa» (switch) | on / off | Sent at once. |

### 5.2 Programar tab
- **Blocks:** Luces, Sonido, Control, plus «esperar a que algo esté a menos de … cm» and «si algo está a menos de … cm».
- **Example** («La trampa…»): green until something is closer than 30 cm, then red and the note «do2» three times.
- **■ Parar or the end:** the board goes back to mode `ghost`.
- **Retos (6):** energy · 3 catches · measure things · a trap · a musical detector · 5 in a minute.

### 5.3 Montar tab
Static: parts, wiring (sensor, LEDs and buzzer), pins VIN/GND/D1/D2/D8 with the resistor divider, 7 steps and the HC-SR04P tip.

---

## 6. 🎮 ¡Salta, Chispa! (`juego.html`)

### 6.1 Opening the page
- A **demo** game plays behind the start screen. It moves, but it never counts or touches the board.
- Everything chosen last time comes back: world, 1 or 2 players, speed, Chispa colour, sound and controls.
- The **«Lo que te vas a encontrar»** card (Jugar tab) and the start screen follow the chosen world.

### 6.2 Start screen
| Element | Action | Expected result |
|---|---|---|
| «¿Cuántos jugáis?» (top left) | 👤 1 jugador / 👥 2 jugadores | Selected one highlighted. Saved: `juego.jugadores`. The chips under ▶ change (6.11). |
| «¿A qué velocidad?» (top right) | 🐢 Tortuga · 5 vidas / 🐇 Normal | Saved: `juego.tortuga`. |
| World picker ‹ «Mundo 1 · El campo 🌵» › | ‹ or › | Cycles campo → granja → luna and back round. Saved: `juego.mundo`. The demo and «Lo que te vas a encontrar» change at once. |
| Locked world | — | ▶ is disabled, and the line «🔒 Se abre ganando a la Cosechadora en <previous world>» shows. |
| **▶ ¡A jugar!** | Click, Enter or Space (it has focus) | Starts a game in that world (6.3). |
| Chips under ▶ (one player) | — | «👆 Tocar» is always on. «🔘 Botón», «👏 Palmada» and «👋 Mano» are on or struck through, following the toggles in «¿Con qué saltas?». |
| Tap the game outside the box, or Space / ↑ / Enter | — | Starts too. |
| An enabled board control (FLASH, a clap, a hand under 15 cm) | — | Starts too. |

### 6.3 Playing (one player)
**Start**
- Banner «¡Corre, Chispa! ⚡», or «🐢 Modo tortuga: 5 vidas».
- 3 lives (5 in Tortuga).
- The board's light turns green.

**Jump** (only from the ground; with the rocket, jumps fly):
- Tap the game
- **⤴ ¡Salta!**
- Space, ↑ or Enter (not while typing in a field)
- 🔘 FLASH, if «Botón» is on
- 👏 a clap reaching the sonómetro's red, if «Palmada» is on
- 👋 a hand moving under 15 cm, if «Mano» is on. It counts once, when the hand enters the zone.

Each board jump flashes «🔘 ¡Botón!», «👏 ¡Palmada!» or «👋 ¡Mano!» in «¿Con qué saltas?».

**Duck** (only from the ground; Chispa gets lower and wider):
- Hold ↓ or S
- Hold **⤵ Agáchate**
- Keep the hand between 15 and 30 cm, if «Mano» is on

**What comes on the road**
- Each world's obstacles («Lo que te vas a encontrar» lists them).
- The **Nubarrón** («¡Cuidado! ¡El Nubarrón tira exámenes! ☁️») drops exams. The first drop is an **examen volador** ✈️ gliding at head height: duck, or jump it.

**Helpers**
- 🛡️ Escudo takes one hit.
- 🚀 Cohete makes jumps fly for 8 s (14 s at the Cosechadora).
- ⏱️ Cámara lenta slows everything for 6 s.
- ⚡ Rayos add to the score and to the bank that opens colours.
- Each power shows its banner, and the HUD ring empties as it runs out.

**HUD**
- Lives and bolts share one pill.
- The road bar shows metres up to the Cosechadora at 800 m.
- The corner tag shows «Récord N m» (🐢 in front in Tortuga).

**Getting hit**
- You lose one life and are safe for 1.5 s; the screen shakes.
- The board shows red for 0.35 s, with a beep only when «Palmada» is off (so the mic doesn't hear the board).

**Sky:** day, evening and night as the metres go by (the moon is always night).

**At 800 m, the Súper Cosechadora**
- It peeks in from the right and throws the bales. Three phases, each with its sign: «Pacas de paja» → «Tres saltos seguidos» → «¡Con el cohete!».
- Jumping it wins (6.5).

**Board lights during a game** (only with the board connected and no block program running):
- start: green
- power: yellow, with a beep if «Palmada» is off
- power ends: yellow off
- hit: red flash
- game over: red
- win: a light show, then all on

### 6.4 Game over screen
**Left column**
- The drawing of what caught you.
- «¡Te ha pillado X!», or «¡Te han pillado X!» for plurals («los deberes»).
- Chips: «📏 N m · ⚡ N rayos · ⤴ N saltos».
- Road bar with «Te faltaban **N m** para la Súper Cosechadora 🚜», or «¡Estabas ante la Súper Cosechadora! 🚜».
- «🏆 ¡Récord nuevo!», or «Récord: N m». The personal best is saved in `juego.record`.
- News chips, when they apply: «🆕 Pegatina: …», «🎨 ¡Nueva Chispa: …!».
- **↻ ¡Otra vez!** (focused) plays the same world again. **☰ Menú** goes back to the start screen.

**Right column, «🏆 Récords de la clase»** (idea 5)
- **If the score makes the top 5:**
  - «¡Entras en el puesto N!», a field «Tu alias» (12 characters max, filled with the last alias), **🎲**, **Guardar**, and «Un alias, no tu nombre de verdad. **No, gracias**».
  - **🎲** fills in a random alias (Rayo, Cometa, Trueno, Pulga, Bólido…).
  - **Guardar** with an empty field: toast «Escribe un alias (o pulsa 🎲)».
  - **Guardar** with an alias: `<>"&` are removed and it is saved. The list redraws with your row highlighted and «✓ Guardado en la placa.», or «✓ Guardado en esta tableta.» on a board without records.
  - **No, gracias** hides the form without saving.
  - While the form is open, taps and board controls don't start a new game. The buttons still work.
- **If it doesn't make the top 5** and the list is full: «Para entrar, hay que pasar de N m.»
- **Rows** show the position, the alias (🐢 for Tortuga, the world's emoji if it isn't the campo) and the metres. With nobody yet: «Todavía nadie. ¡Estrénalos!»

**Starting again:** for 0.9 s after the screen appears, taps and board controls are ignored, so a late jump doesn't restart. The buttons work at once.

### 6.5 Win screen
- **Stars by bolts:** under 10 is ⭐, 10–24 is ⭐⭐, 25 or more is ⭐⭐⭐. The others show grey.
- «¡Has saltado la Súper Cosechadora!» and the chips «📏 m · ⚡ rayos · ⏱ s».
- «La siguiente estrella, con N rayos. ¿Te atreves?», or «¡Las tres estrellas! Eres una chispa de verdad.»
- **Winning a world opens the next one** and gives stickers (🚜, plus 🐔 or 👽 in worlds 2 and 3). The news chips add «🔓 ¡Nuevo mundo: …!». Saved: `juego.mundos`.
- Buttons: **↻ ¡Otra vez!**, **«<emoji> Ir a <next world>»** (only when there is a next world; starts it straight away) and **☰ Menú**.
- Same records column as 6.4. Confetti.

### 6.6 Two players (idea 1)
**Start:** choose 👥 2 jugadores, then ▶.
- The frame grows taller: player 1 on top, player 2 below, with a line between them.
- Both get the same obstacles. Player 2 is Menta if player 1 is Chispa (otherwise Chispa).
- Banners: «🔘 Jugador 1: ¡con el botón!» / «👏 Jugador 2: ¡con palmadas!».
- The game bar shows **Jugador 1** and **Jugador 2** buttons.

| | Player 1 | Player 2 |
|---|---|---|
| Jump | FLASH · A or W · «Jugador 1» · tap the top half | clap · L or ↑ · «Jugador 2» · tap the bottom half |
| Duck | S · «Agáchate» · hand at 15–30 cm | K or ↓ |

- In two-player mode the board controls always count, even if switched off in «¿Con qué saltas?». The hand never jumps.
- A player who is out keeps their sign on their half while the other plays on.
- **When both are done:** «¡Gana el jugador N!» (🔘🏆 or 👏🏆) or «¡Empate!» (🤝).
  - The winner is whoever went farther; with equal metres, more bolts; otherwise a tie.
  - Each player's card shows metres, bolts and what caught them.
- **Buttons:** **↻ ¡Revancha!** (two players again) and **☰ Menú**.
- No personal or class records in two-player mode. Both players' bolts still go to the bank that opens colours.

### 6.7 Game bar (under the game)
| Button | Result |
|---|---|
| ⤴ ¡Salta! | Jump (in two-player mode it is «Jugador 1»). |
| Jugador 2 | Two-player mode only: player 2 jumps. |
| ⤵ Agáchate | Duck while held. |
| 🔊 Con sonido / 🔇 Sin sonido | Turns the game's sounds on or off. Saved: `juego.mudo`. |
| ⛶ Pantalla completa | The game fills the screen; press again (or Esc) to leave. Hidden on browsers without fullscreen. |
| «📱 Gira el móvil…» | Shown on phones held upright. |

### 6.8 Jugar tab (below the game)
1. **«¿Con qué saltas?»**
   - **Toggles:** 🔘 Botón FLASH, 👏 Palmada, 👋 Mano. Each click switches that control on or off. Saved: `juego.mandos`; the default is only the button on. The start-screen chips update.
   - **Live line:** «Placa lista: ¡prueba tu mando!», «Sin placa: juega tocando la pantalla o con la barra espaciadora.», or a flash of the last control used.
   - **Live signal:** «👏 Ruido» is a bar with a mark at the sonómetro's red. «👋 Mano» is a bar with a mark at 15 cm and a purple zone from 15 to 30 cm (duck). Each shows its number («N» / «N cm» / «—»). The bars move even when that control is off.
2. **«Elige tu Chispa»:** five colours.
   - Chispa (0 ⚡), Menta (20), Uva (50), Fresa (100), Hielo (160).
   - Open colours say «Elegir». Click to choose it; it then says «✓ La tuya». Saved: `juego.skin`.
   - A locked colour says «🔒 N ⚡». Clicking it shows the toast «🔒 Uva se abre con 50 rayos. ¡Llevas N!».
   - Below: «Llevas **N ⚡** juntados en todas tus partidas. La siguiente, X, con N.», or «¡Las tienes todas!». Saved: `juego.rayosTotal`.
3. **«Pegatinas ⭐ N de 9»:** each sticker shows its emoji, name and how to get it, or «¡Conseguida!».
   - The nine: 10 deberes · Noche sin chocar · La Cosechadora · 3 escudos · 50 rayos · 5 brócolis · Agachado · La granja · La luna.
   - Saved: `juego.pegatinas`, with counters in `juego.cuentas`.
4. **«🏆 Récords de la clase»:** the same top 5, plus either «Los cinco mejores, guardados en la placa…» or «Esta placa no guarda récords, así que se guardan en esta tableta.»
5. **«Lo que te vas a encontrar · <world>»:** that world's obstacles, plus Nubarrón, Examen volador and Súper Cosechadora («en 800 m, en 3 fases»), and «Lo que te ayuda» (escudo, cohete, cámara lenta, rayos).

### 6.9 Programar tab
- **Bubble:** the yellow «⚡ cuando Chispa…» blocks start by themselves every time something happens, and several can run at once.
- **Blocks:** Luces, Sonido, Control, plus «esperar a que Chispa…», «si Chispa tiene…» and «⚡ cuando Chispa…».
- **Example:** two «⚡ cuando» blocks, green for 0.3 s on every jump and red with «do» on every hit. Its text: «Dos «cuando» a la vez…».
- **While a program runs**, the game stops driving the lights itself; the program owns them.
- **Retos (6):** blink green on each jump · beep on each hit · a note on each bolt · yellow while the rocket is on · one more light per Cosechadora phase · a victory song.

### 6.10 Montar tab
- Parts list (nothing new to build).
- Wiring drawing (LEDs, mic and sensor; buzzer dimmed).
- Pins table: FLASH D3, mic A0, sensor D1/D2, lights D5/D6/D7.
- Note that the class records need firmware to be stored on the board.

### 6.11 Start-screen chips in two-player mode
«J1 · 🔘 botón · tecla A · tocar arriba» and «J2 · 👏 palmada · tecla L · tocar abajo».

---

## 7. Everything that is saved (`localStorage`, prefix `lab.`)

| Key | What |
|---|---|
| `retos.<page>` | ticked retos |
| `programa.<page>` | the block program of each page |
| `juego.record` | personal best (metres) |
| `juego.mudo` | game sound off |
| `juego.mandos` | which controls jump (button, clap, hand) |
| `juego.mundo`, `juego.mundos` | chosen world · worlds won |
| `juego.tortuga`, `juego.jugadores` | speed · 1 or 2 players |
| `juego.skin`, `juego.rayosTotal` | Chispa colour · bolts collected in all games |
| `juego.pegatinas`, `juego.cuentas` | stickers · counters for stickers |
| `juego.clase`, `juego.alias` | class records when the board has none · last alias |
| `juego.abierto` | everything unlocked (prototype tool, see 9) |
| `sonometro.record` | loudest clap |
| `fantasmas.cazados`, `fantasmas.contrarreloj` | ghosts caught · best minute |
| `semaforo.luzroja` | best «Luz roja, luz verde» time |

## 8. Board calls each page makes

| Page | Calls |
|---|---|
| Home | `state` |
| Semáforo | `state`, `mode` (manual / auto / night), `light`, `walk`, `settings` (trafficSpeed), `beep` |
| Sonómetro | `state`, `mode` (sound), `settings` (soundYellow / soundRed / soundGain / soundAlarm), `light` (duel and blocks), `beep` (blocks) |
| Fantasmas | `state`, `mode` (ghost), `settings` (ghostNear / ghostFar / ghostSound), `light` and `beep` (blocks) |
| ¡Salta, Chispa! | `state`, `input`, `light`, `beep`, `records`, `record` |

`records` and `record` don't exist in today's firmware. The game notices and keeps the records on the tablet instead.

---

## 9. Prototype only (not part of the app)

- **`?sim=quiet`:** the fake board's sensors stay still (no noise, no echo).
- **`?prueba=1` and `Juego.prueba`:** test helpers.
- **`Juego.abrirTodo()`:** opens every world and colour.
- **`Laboratorio - Juegos v3.dc.html`:** the tour page. Each game sits in a frame with a «La placa» panel:
  - Game: «🔘 Botón FLASH», «👏 Palmada», «👋 Mano a 8 cm», «✋ Mano a 22 cm» (hold to duck) and an unlock-all button
  - Sonómetro: «🗣️ Charla» / «🤫 Silencio» and «👏 Palmada»
  - Detector: «👻 Viene solo» / «✋ A mano» and a distance slider
  - «Luz roja, luz verde»: a distance slider, «🚶 Un paso» and «↩ A la salida»
- The semáforo frame now scrolls itself down to «Luz roja, luz verde» when it loads.

---

## 10. Review of 6 October 2026: what was checked and changed

### 10.1 Fixed (didn't behave as designed)
1. **Semáforo: «Luz roja, luz verde» was on top of the traffic light.**
   - v3 had put the new card first in the Jugar grid, so the bubble «Toca una luz para encenderla» pointed at lights pushed below the game (a whole screen down on a phone).
   - The card now comes after the traffic light and «¿Quién manda?». The tour page scrolls to it.
   - Files: `lab-v3/semaforo.html`, `Laboratorio - Juegos v3.dc.html`.
2. **Sonómetro: the clap duel could miss claps.**
   - It only looked at the noise level at each poll. A short clap between polls (slow tablet, or a hidden tab polling every 2 s) counted low or as 0.
   - The board's 2-second peak now also counts, as long as it rose after «AHORA», so the countdown's noise still doesn't count.
   - File: `lab-v3/sonometro.js`.
3. **Sonómetro: «¡Empezar!» and «¡Medir!» did nothing during a duel.** They now say «Espera a que acabe el duelo 😉», the same way the duel button already warned about the other games. File: `lab-v3/sonometro.js`.
4. **Fantasmas: the countdown clock never went away.** After the minute, «⏱ 0:00» stayed on top of the ghost until the page was reloaded. It now hides 4 s after the result. File: `lab-v3/fantasmas.js`.

### 10.2 Checked and working (simulator)
- All five pages load without console errors.
- All 13 page and tab views fit a 360 px screen with no sideways scroll.
- **¡Salta, Chispa!:**
  - start screen, worlds and lock, 1 / 2 players, Tortuga (5 lives)
  - jump with keys and screen; duck with ↓, «Agáchate» and release
  - game over texts and plural, «Te faltaban…», record
  - alias form (`<b>` stripped, «Guardado en la placa»)
  - win with stars, «Ir a La luna» and the records column
  - two-player result («¡Empate!»), colours, stickers counter
  - the example program loads with the right colours and times and runs
- The block engine's events count jumps.

### 10.3 Known gaps (left as they are)
- The win-star thresholds (10 and 25 bolts) are still placeholders.
- Class records on the board need two firmware endpoints; until then they stay on each tablet.
- «Duelo de palmadas», «Caza contrarreloj» and «Luz roja, luz verde» depend on real-time timers. The preview used for this review slows hidden pages down, so they were checked by reading the code, not by playing. They still need one round by hand with a real board.
- «Jugador 2» and «Agáchate» react to touch and mouse only; on a keyboard, L / ↑ and ↓ / S do the same.
- In two-player mode, a hand at 15–30 cm makes player 1 duck even when «Mano» is off.
- The «/api» link on the home page is `#` in the prototype copy; on the board it must open `/api`.
- Not built (only drawn in «Juegos - Mejoras»): a big silence screen with the day's top 3 claps, and a ghost album.
