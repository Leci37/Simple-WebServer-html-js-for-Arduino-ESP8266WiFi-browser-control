# Handoff: Laboratorio de inventos v3 → `web/`

## Overview
`lab-v3/` is the new version of the Laboratorio de inventos web: a redesigned **¡Salta, Chispa!** plus 12 game ideas. Three of them are new mini-games inside the existing Sonómetro, Detector de fantasmas and Semáforo pages.

It was built on a verbatim copy of `web/` from branch `_ztool_main` (taken 2026-10-05), so every file maps 1:1 to a file in `web/`. Every change is marked in the code:
- JS: `// v2:` or `// v3 (idea N):`
- HTML: `<!-- v3 (idea N) -->`
- CSS: blocks appended at the end of `app.css`, commented `v2` or `/* Idea N */`

`grep -n "v2\|v3\|Idea [0-9]" lab-v3/*` lists them; `diff -r web lab-v3` shows everything.

## About these files
They are the reference for look and behaviour. They are already written in the repo's own style: no framework, `var`/`function`, same file split, the same `Lab.*` helpers from `app.js`, and `async` only inside block runners (as `bloques.js` already does). Code can be lifted where it meets CLAUDE.md.

To try them, open `lab-v3/index.html` in a browser. No board needed: `simulador.js` answers `/api/...` inside the browser.
- `?sim=quiet`: sensors stay still (like `simulador.py --quiet`).
- `Juego.abrirTodo()` in the console of `juego.html`: opens worlds 2–3 and every Chispa colour without earning them.

### Not part of the port
- `simulador.js` and the `<script src="simulador.js">` line at the top of every page. It is a JS port of `tools/simulador.py`, only for running without a board. Don't add it to `web/`. Its `/api/records` and `/api/record` handlers document the contract below.
- Relative paths (`href="app.css"`): the copy turned `web/`'s absolute paths into relative ones. Keep `web/`'s.
- `?capturas=1`: a screenshot helper inside `simulador.js`.

## Fidelity
High fidelity: final colours, spacing, copy (Spanish, «tú») and behaviour. System fonts only. Everything is drawn with canvas or inline SVG, and nothing loads from the internet. No inline scripts and no `on*=` attributes. All five pages keep `lang="es"`, viewport, `<title>`, `data-conn` and `data-board-name`.

## Inventory (vs `web/`)
There are **no new pages**. The new games live inside the four existing pages, and `index.html` is unchanged.

Sizes are from the `web/` copy to `lab-v3/`, without `simulador.js`. KB = 1000 bytes; gzip at the default level. Measure the real build with `tools/build_web.py`.

| File | Status | What changed | Raw KB | gzip KB |
|---|---|---|---|---|
| `juego.js` | changed | v2 HUD and screens, Programar tab, ideas 1–9 | 53.3 → 101.7 | 16.2 → 30.4 |
| `juego.html` | changed | start / over / win / two-player screens, game bar, Jugar · Programar · Montar tabs, new cards | 5.2 → 13.6 | 1.7 → 3.6 |
| `app.css` | changed | blocks appended at the end | 38.8 → 52.7 | 8.9 → 11.4 |
| `bloques.js` | changed | «⚡ cuando…» hat blocks that run at the same time (idea 7) | 27.5 → 28.2 | 7.7 → 7.9 |
| `sonometro.html` / `.js` | changed | idea 10 card, reto 6 | 9.9 → 11.3 / 10.1 → 15.5 | 3.0 → 3.4 / 3.5 → 4.9 |
| `fantasmas.html` / `.js` | changed | idea 11 card and radar overlay, reto 6 | 11.3 → 12.2 / 6.9 → 8.9 | 3.5 → 3.8 / 2.6 → 3.2 |
| `semaforo.html` / `.js` | changed | idea 12 card, one line in the parts list | 9.8 → 10.9 / 4.3 → 8.7 | 2.9 → 3.3 / 1.6 → 3.1 |
| `index.html`, `app.js`, `esquema.js`, `inicio.js`, `favicon.svg` | unchanged | — | — | — |
| **Total (15 files)** | | | **218.8 → 305.3** | **65.0 → 88.3** |

## ¡Salta, Chispa! (`juego.html`, `juego.js`)
Page order: topbar → game card (canvas + overlay screens) → game bar → tabs Jugar / Programar / Montar → footer. The tabs sit below the game, so the game stays in view (v2).

### Canvas HUD (v2)
- Lives and bolts share one pill.
- The metres are drawn inside the road progress bar. Before, they sat underneath and showed through the signs.
- Each active power has a ring that empties, instead of a thin bar.
- Start banner: «¡Corre, Chispa! ⚡», or «🐢 Modo tortuga: 5 vidas».
- Corner tag: «Récord N m» (🐢 in front in turtle mode), «🔘 Jugador 1» / «👏 Jugador 2» in two-player mode, «DEMO».

### Start screen (`#screen-start`)
- Top corners: «¿Cuántos jugáis?» (👤 1 jugador / 👥 2 jugadores) and «¿A qué velocidad?» (🐢 Tortuga · 5 vidas / 🐇 Normal). The `.long` parts hide on small frames.
- World picker: ‹ «Mundo 1 · El campo 🌵» ›. A locked world shows why in `#world-lock`.
- ▶ ¡A jugar!
- `#start-mandos`: one chip per control (button, clap, hand). On = enabled, struck through = off. They follow the toggles in «¿Con qué saltas?».

### Game over (`#screen-over`)
- Sprite of what caught you and the title «¡Te ha pillado X!» or «¡Te han pillado X!». The plural comes from `KINDS[k].plural` and fixes «te ha pillado los deberes».
- Chips for metres, jumps and bolts. Road bar with «Te faltaban N m para la Súper Cosechadora 🚜» (`FINAL_M = 800`). Record line. `.ov-news` lists stickers and colours unlocked in this game.
- Buttons: ¡Otra vez! / ☰ Menú.
- Right column `.ov-side`: class records, plus the alias form when you make the top 5 (idea 5).

### Win (`#screen-win`)
- One to three stars by bolts (`WIN_STARS = [10, 25]`): under 10 is ⭐, 10–24 is ⭐⭐, 25 or more is ⭐⭐⭐. The text says «La siguiente estrella, con N rayos. ¿Te atreves?», or «¡Las tres estrellas! Eres una chispa de verdad.»
- **The 10 and 25 thresholds are placeholders. Nobody has decided them.**
- `#win-world` takes you to the next world once it's open. Same `.ov-side` column.

### Two-player result (`#screen-duo`)
🏆, «¡Gana el jugador N!», both scores, ¡Revancha! / ☰ Menú.

### Game bar
¡Salta! · Jugador 2 (two-player only) · Agáchate · 🔊 Con sonido · ⛶ Pantalla completa, then the hint «📱 Gira el móvil para ver el juego más grande.»

### Jugar tab (cards in `.play-grid`)
1. **¿Con qué saltas?** Three toggles (Botón FLASH / Palmada / Mano), `#mando-live`, and the **live signal** (v2): two bars with the line you have to pass. Noise is measured against the sonómetro's red (`soundRed`, 70 by default), the hand against 15 cm. The hand bar has a purple zone from 15 to 30 cm, where Chispa ducks. The bars move even when that control is off. The data comes from `/api/input`.
2. **Elige tu Chispa** (idea 2): `#skins`, `#bank`.
3. **Pegatinas** (idea 6): `#stickers`.
4. **🏆 Récords de la clase** (idea 5): `#class-table`, `#class-where`.
5. **Lo que te vas a encontrar**: the selected world's obstacles, plus the helpers (escudo, cohete, cámara lenta, rayos).

### Programar tab
Block editor (`Bloques.mount`, key `juego`) with light_on, light_off, lights_off, beep, note, wait, repeat, forever and three game blocks:
- `wait_game`: «esperar a que Chispa …»
- `if_power`: «si Chispa tiene …»
- `when_game` (idea 7)

The example program has two «⚡ cuando» blocks: green on each jump; red plus the note «do» on each hit. There are six retos; ids 1–6 are listed in the order 1, 2, 3, 4, 6, 5.

### Montar tab
Parts list, wiring (`Esquema.draw` with leds, mic and sonar; buzzer dimmed) and the pins table: FLASH D3, mic OUT A0, TRIG/ECHO D1/D2, lights D5/D6/D7. The note says class records on the board need firmware that stores them; without it they stay on the tablet.

## The 12 ideas
1. **Dos jugadores** (`startDuo`, `.game-frame.duo`). Split screen: two worlds stacked on an 800×600 canvas (frame `padding-top: 75%`), with a line between them. Player 1 jumps with FLASH (or key A). Player 2 jumps with a clap, key L or the «Jugador 2» button. The hand is ignored in two-player mode. Each player plays until caught, and whoever is out keeps their sign while the other plays on. The farthest wins → `#screen-duo`.
2. **Elige tu Chispa** (`SKINS`). Chispa `#ffd84d` (0 bolts), Menta `#6fe3a6` (20), Uva `#c4a3ff` (50), Fresa `#ff9fc2` (100), Hielo `#9fe6ff` (160). Bolts add up across games (`juego.rayosTotal`), and the chosen colour is stored in `juego.skin`.
3. **Mundos** (`WORLDS`, `WORLD_ORDER`).
   - Campo 🌵: cactus, deberes, cactus2, brócoli, mates, coche.
   - Granja 🐔: valla, deberes, gallina, cerdo, mates, coche.
   - Luna 🌙: roca, cráter, deberes, alien, mates; gravity 1650, jump speed 690.
   - Each world has three palettes (day, evening, night). Winning world 1 opens world 2, and winning world 2 opens world 3 (`juego.mundos`).
4. **Final con fases** (`PHASES`, `startBoss`). «Pacas de paja» → «Tres saltos seguidos» → «¡Con el cohete!», each with its sign on the canvas. The Cosechadora peeks in from the right and throws the bales. Each phase fires the block event `phase`.
5. **Récords de la clase** (`loadClass`, `saveClass`, `paintSide`). Top 5 entries of `{alias, m, t, w}`.
   - When you make it, a form asks for an alias: 12 characters max, `<>"&` stripped, 🎲 picks one of 12 aliases, «No, gracias» skips. The last alias is remembered (`juego.alias`).
   - Rows show 🐢 for turtle mode and the world's emoji when it isn't the campo.
   - Records go to the board through the API below. If the board doesn't answer, they fall back to `juego.clase` in localStorage with «Esta placa no guarda récords, así que se guardan en esta tableta.»
6. **Pegatinas** (`STICKERS`, `earn`). Nine stickers: 📚 10 deberes, 🌙 Noche sin chocar, 🚜 La Cosechadora, 🛡️ 3 escudos, ⚡ 50 rayos, 🥦 5 brócolis, ✋ Agachado (dodge 3 flying exams by ducking), 🐔 La granja (win world 2), 👽 La luna (win world 3). They are stored in `juego.pegatinas`, with counters in `juego.cuentas`. A new sticker shows a sign and appears in the end screen's news.
7. **Eventos** (`when_game`). «⚡ cuando Chispa [salte | choque | coja un rayo | coja un poder | pierda | gane | se agache | pase de fase]». It runs its body every time the event happens, and several can run at once. It sits in the yellow «⚡ Eventos» category. See the engine change below.
8. **Agacharse**. A hand at 15–30 cm (`HAND_CM = 15`, `DUCK_CM = 30`), ↓ or «Agáchate» makes Chispa duck, only while on the ground (height `DUCK_H = 34`). New obstacle «examen volador» ✈️: the first thing each Nubarrón drops is a paper plane that glides down to head height.
9. **Modo tortuga**. Speed × `TURTLE`, gaps × 1.35, 5 lives instead of 3 (`juego.tortuga`). Records get a 🐢.
10. **Duelo de palmadas** (`sonometro.js`, from «idea 10»).
    - Two teams, 🔴 rojo and 🟢 verde, take turns of 2.5 s; the loudest clap counts. Three rounds; whoever wins two takes it.
    - The board's light shows who is ahead: red, green, or yellow when tied. The winner's light blinks.
    - Afterwards the lights go back to `mode=sound`. It won't start while the silence or clap game is running. Reto 6.
11. **Caza contrarreloj** (`fantasmas.js`, from «idea 11»). 60 s, with a big clock and score over the radar (`#hunt-clock`, `.hurry` in the last 10 s). Record in `fantasmas.contrarreloj`. Reto 6: «¿llegas a 5 fantasmas…».
12. **Luz roja, luz verde** (`semaforo.js`, from «idea 12»).
    - You start more than 40 cm from the board; it refuses with no echo or when you're closer.
    - Green: walk towards the board. Red: freeze. After a short grace period, a distance change of more than 6 cm (`MOVE_CM`) sends you back to the start. Reaching `GOAL_CM = 12` wins.
    - Time record in `semaforo.luzroja`. Lights through `/api/light`, beeps through `/api/beep` (330 Hz / 200 ms and 196 Hz / 400 ms). Afterwards it returns to `mode=auto`.
    - It reads `state.ghost.cm` from `/api/state`. The firmware pings the sensor in every mode (`ghostLoop` in `laboratorio/ghost.h` doesn't check the mode), so no firmware change is needed.

## Block engine change (`bloques.js`, the only shared-code change)
- New category `eventos: "⚡ Eventos"`.
- A block definition can set `hat: true`. Hats get a hat top (`bk-hat-top`), always go into the top-level program (never nested) and hold blocks inside like a C block.
- `Editor.run` runs the hats at the same time as the rest (`Promise.all`) and stops once everything has ended.
- Pages without hats behave exactly as before.

## Board API
v3 uses `state`, `input`, `mode`, `settings`, `light`, `beep` and `walk`. All of them exist in today's firmware (`laboratorio/web_api.h`).

Two new endpoints are **optional**: `records` and `record`. They aren't in the firmware, and the game works without them by falling back to the tablet. The contract, as `simulador.js` implements it, called like the others (`Lab.api("records")`, `Lab.api("record", {...})`):
- `/api/records` → `{"records":[{"alias":"Rayo","m":906,"t":0,"w":"campo"}, …]}`, best first, at most 5.
- `/api/record` with `alias`, `m`, `t` (0 or 1) and `w` (campo, granja or luna):
  - Strip `<>"&` from the alias, trim it and keep 12 characters.
  - If the alias is empty or `m <= 0`: 400 `{"error":"hace falta un alias y los metros"}`.
  - Otherwise insert, sort by `m` (highest first), keep 5 and reply `{"records":[…],"place":N}` (`place` is 0 if it didn't make it).
- The simulator starts with four example aliases; the board should start empty.

## localStorage keys added (through `Lab.store`)
- `juego.mundo`, `juego.tortuga`, `juego.jugadores`, `juego.skin`, `juego.rayosTotal`, `juego.mundos`, `juego.pegatinas`, `juego.cuentas`, `juego.abierto`, `juego.clase`, `juego.alias`
- `fantasmas.contrarreloj`, `semaforo.luzroja`

Kept: `juego.record`, `juego.mudo`, `juego.mandos`, `sonometro.record`, `fantasmas.cazados`.

## Test hooks
- `window.Juego.state()` returns more fields than before: world, turtle, duck, boss step, duo, stickers, bank, things on screen, block events and whether a program is running. See the end of `juego.js`.
- `Juego.abrirTodo()` is new.
- `?prueba=1` still gives `Juego.prueba` (actualiza, dibuja, nube, skipTo, invencible, piloto, rapido, poder).

## Known open items
- The win-star thresholds (10 and 25 bolts) are undecided.
- Class records on the board: the firmware endpoints aren't written yet. The game falls back to the tablet.
- Ideas 10–12 have only run in the simulator. Nobody has played them by hand or on a real board.
- Not every page has been checked at 360 px.
- Two ideas were only drawn, never built, and are outside this port: a big silence-challenge screen with the day's top 3 claps, and a ghost album (one photo per catch).

## Assets
No images or fonts. Sprites are drawn on canvas in `juego.js`, and `favicon.svg` is unchanged.

## Files (`lab-v3/`)
- `index.html`, `inicio.js`: home page (unchanged)
- `app.css`, `app.js`: shared styles and helpers (CSS extended, JS unchanged)
- `bloques.js`: block editor (hat blocks)
- `esquema.js`: wiring diagrams (unchanged)
- `juego.html`, `juego.js`: ¡Salta, Chispa!, ideas 1–9
- `sonometro.html`, `sonometro.js`: idea 10
- `fantasmas.html`, `fantasmas.js`: idea 11
- `semaforo.html`, `semaforo.js`: idea 12
- `simulador.js`: fake board for the browser (not part of the port)
- `favicon.svg`

`USER_FLOW.md` (next to this README) describes every screen, click and expected result. Its section 10 lists four fixes made after the first handoff: the «Luz roja, luz verde» card now sits below the traffic light; the clap duel also counts the board's peak; «¡Empezar!» / «¡Medir!» warn during a duel; and the ghost-hunt clock hides after the minute.
