/* Placa de mentira para ver la rama _ztool_main sin NodeMCU.
   Es tools/simulador.py pasado a JavaScript: contesta a /api/... dentro del
   navegador. ?sim=quiet deja los sensores quietos (como --quiet). */
(function () {
  "use strict";
  // Sólo para hacer capturas con la pestaña escondida: ?capturas=1.
  if (/[?&]capturas=1/.test(location.search)) {
    window.requestAnimationFrame = function (cb) { return setTimeout(function () { cb(performance.now()); }, 16); };
    try { Object.defineProperty(document, "hidden", { get: function () { return false; } }); } catch (e) {}
  }
  var MODES = ["manual", "auto", "night", "sound", "ghost"];
  function now() { return Date.now(); }
  var quiet = /[?&]sim=quiet/.test(location.search);
  var b = {
    start: now(), mode: "auto", leds: { red: false, yellow: false, green: false },
    phase: "green", phaseAt: now(), walkRequested: false, walkBeeps: false,
    button: 0, beeps: 0,
    sound: { level: 0, peak: 0, raw: 0, mic: true, claps: 0 },
    peakAt: 0, clapAt: -1000, wasLoud: false,
    ghost: { cm: -1, level: 0, sensor: true },
    forcedSound: quiet ? 0 : null, forcedCm: quiet ? -1 : null,
    spikeAt: -1e12, handUntil: 0, handCm: 8,
    settings: { soundYellow: 45, soundRed: 70, soundGain: 100, soundAlarm: false,
      ghostNear: 20, ghostFar: 60, ghostSound: true, trafficSpeed: 2 }
  };
  function setMode(m) {
    if (m === b.mode) return;
    b.mode = m; b.leds = { red: false, yellow: false, green: false };
    b.phase = "green"; b.phaseAt = now(); b.walkRequested = false; b.walkBeeps = false;
  }
  function pressButton() {
    b.button += 1; b.beeps += 1;
    if (b.mode === "auto" && b.phase !== "red") b.walkRequested = true;
  }
  function duration(p) {
    var sp = Math.min(3, Math.max(1, b.settings.trafficSpeed)) - 1;
    var t = { green: [8000, 5000, 3000], yellow: [3000, 2000, 1000], red: [8000, 5000, 3000] };
    return t[p][sp];
  }
  function ghostLevel(cm) {
    var near = b.settings.ghostNear, far = b.settings.ghostFar;
    if (cm < 0 || cm > far) return 0;
    if (cm <= Math.floor(near / 2)) return 5;
    if (cm <= near) return 4;
    return 1 + Math.floor((far - cm) * 3 / (far - near + 1));
  }
  function readSensors(n) {
    var t = (n - b.start) / 1000, level;
    if (b.forcedSound !== null) level = b.forcedSound;
    else {
      level = 22 + 8 * Math.sin(t * 1.3) + (Math.random() * 8 - 4);
      var sc = t % 7;
      if (sc < 1.2) level = Math.max(level, 92 - sc * 40);
    }
    var since = (n - b.spikeAt) / 1000;
    if (since >= 0 && since < 1.2) level = Math.max(level, 96 - since * 40);
    level = Math.floor(Math.max(0, Math.min(100, level * b.settings.soundGain / 100)));
    b.sound.level = level;
    b.sound.raw = Math.floor(4 * Math.pow(10, level / 100 * Math.log10(700 / 4)));
    if (level >= b.sound.peak || n - b.peakAt > 2000) { b.sound.peak = level; b.peakAt = n; }
    var loud = level >= b.settings.soundRed;
    if (loud && !b.wasLoud && n - b.clapAt >= 300) { b.sound.claps += 1; b.clapAt = n; }
    b.wasLoud = loud;
    var cm;
    if (n < b.handUntil) cm = b.handCm;
    else if (b.forcedCm !== null) cm = b.forcedCm;
    else cm = Math.floor(70 + 62 * Math.sin(t * 0.45));
    b.ghost.cm = cm; b.ghost.level = ghostLevel(cm);
  }
  function tick() {
    var n = now();
    readSensors(n);
    if (b.mode === "auto") {
      var el = n - b.phaseAt;
      if (b.phase === "green" && (el >= duration("green") || (b.walkRequested && el >= 1000))) { b.phase = "yellow"; b.phaseAt = n; }
      else if (b.phase === "yellow" && el >= duration("yellow")) { b.phase = "red"; b.phaseAt = n; b.walkBeeps = b.walkRequested; b.walkRequested = false; }
      else if (b.phase === "red" && el >= duration("red")) { b.phase = "green"; b.phaseAt = n; b.walkBeeps = false; }
      b.leds = { red: b.phase === "red", yellow: b.phase === "yellow", green: b.phase === "green" };
    } else if (b.mode === "night") {
      b.leds = { red: false, yellow: Math.floor(n / 500) % 2 === 0, green: false };
    } else if (b.mode === "sound") {
      var lv = b.sound.level, s = b.settings, red = lv >= s.soundRed, yel = !red && lv >= s.soundYellow;
      b.leds = { red: red, yellow: yel, green: !red && !yel };
    } else if (b.mode === "ghost") {
      var gl = b.ghost.level;
      if (gl === 0) b.leds = { red: false, yellow: false, green: true };
      else if (gl <= 3) b.leds = { red: false, yellow: true, green: false };
      else { var half = gl === 5 ? 120 : 300; b.leds = { red: Math.floor(n / half) % 2 === 0, yellow: false, green: false }; }
    }
  }
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  function state() {
    return { mode: b.mode, leds: copy(b.leds), walk: b.mode === "auto" && b.phase === "red", button: b.button,
      sound: copy(b.sound), ghost: copy(b.ghost), settings: copy(b.settings),
      board: { name: "Laboratorio-SIM", address: "192.168.4.1", accessPoint: true, version: "1.1.0", uptime: now() - b.start } };
  }
  function argInt(a, k, f) { if (!(k in a)) return f; var v = parseInt(parseFloat(a[k]), 10); return isNaN(v) ? 0 : v; }
  function argBool(a, k, f) { if (!(k in a)) return f; return ["1", "true", "on"].indexOf(String(a[k]).toLowerCase()) >= 0; }
  function handle(path, a) {
    tick();
    if (path === "/api/state") return [200, state()];
    if (path === "/api/input") return [200, { button: b.button, claps: b.sound.claps, cm: b.ghost.cm, level: b.sound.level }];
    if (path === "/api/mode") {
      if (MODES.indexOf(a.set) < 0) return [400, { error: "set tiene que ser manual, auto, night, sound o ghost" }];
      setMode(a.set); return [200, state()];
    }
    if (path === "/api/light") {
      var c = a.color;
      if (["red", "yellow", "green", "all"].indexOf(c) < 0) return [400, { error: "color tiene que ser red, yellow, green o all" }];
      setMode("manual");
      if (c === "all") { var on = argBool(a, "on", !(b.leds.red || b.leds.yellow || b.leds.green)); b.leds = { red: on, yellow: on, green: on }; }
      else b.leds[c] = argBool(a, "on", !b.leds[c]);
      return [200, state()];
    }
    if (path === "/api/beep") { b.beeps += 1; return [200, state()]; }
    if (path === "/api/walk") { pressButton(); return [200, state()]; }
    if (path === "/api/settings") {
      var s = copy(b.settings);
      var lim = { soundYellow: [0, 100], soundRed: [0, 100], soundGain: [10, 1000], ghostNear: [2, 400], ghostFar: [3, 400], trafficSpeed: [1, 3] };
      Object.keys(lim).forEach(function (k) { s[k] = Math.min(lim[k][1], Math.max(lim[k][0], argInt(a, k, s[k]))); });
      ["soundAlarm", "ghostSound"].forEach(function (k) { s[k] = argBool(a, k, s[k]); });
      if (s.soundYellow >= s.soundRed) return [400, { error: "soundYellow tiene que ser menor que soundRed" }];
      if (s.ghostNear >= s.ghostFar) return [400, { error: "ghostNear tiene que ser menor que ghostFar" }];
      b.settings = s; return [200, state()];
    }
    if (path === "/api") return [200, { api: ["GET /api/state", "…"] }];
    return [404, { error: "esa orden no existe: mira /api" }];
  }
  var realFetch = window.fetch ? window.fetch.bind(window) : null;
  window.fetch = function (input, opts) {
    var url = typeof input === "string" ? input : input.url;
    var u = new URL(url, location.href);
    var m = u.pathname.match(/\/api(\/[a-z]*)?$/);
    if (!m) return realFetch(input, opts);
    var args = {};
    u.searchParams.forEach(function (v, k) { args[k] = v; });
    var r = handle("/api" + (m[1] || ""), args);
    return new Promise(function (resolve) {
      setTimeout(function () {
        resolve(new Response(JSON.stringify(r[1]), { status: r[0], headers: { "Content-Type": "application/json" } }));
      }, 15);
    });
  };
  window.LabSim = {
    board: b,
    tick: tick,
    press: function () { tick(); pressButton(); },
    clap: function () { b.spikeAt = now(); },
    hand: function (ms, cm) { b.handCm = cm == null ? 8 : cm; b.handUntil = now() + (ms || 700); },
    setSound: function (v) { b.forcedSound = v; },
    setCm: function (v) { b.forcedCm = v; },
    snapshot: function () { tick(); return state(); }
  };
})();
